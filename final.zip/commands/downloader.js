// ================================================
// DOWNLOADER COMMANDS
// Built only on public APIs that are actually documented and
// reachable right now. No "coming soon" filler commands.
// ================================================

const axios = require('axios');
const yts = require('yt-search');
const config = require('../config');

function usage(cmd, example) {
    return `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${cmd}\n${example ? `║💀║ ➫ 𝑬𝒙: ${example}\n` : ''}╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

module.exports = {
    category: '𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑹',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑹 ⚡
╠═════════════════╣
║ ✰〔〔 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑹 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}tiktok <url> — video, no watermark
║┃💀┃ ➫ ${p}ttmp3 <url> — TikTok audio
║┃💀┃ ➫ ${p}ytsearch <query> — search YouTube
║┃💀┃ ➫ ${p}ytinfo <url> — video info/thumbnail
║┃💀┃ ➫ ${p}pinterest <query> — image search
║┃💀┃ ➫ ${p}img <query> — general image search
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒕𝒊𝒌𝒕𝒐𝒌
║┃💀┃ ➫ .𝒕𝒕𝒎𝒑𝟑
║┃💀┃ ➫ .𝒚𝒕𝒔𝒆𝒂𝒓𝒄𝒉
║┃💀┃ ➫ .𝒚𝒕𝒊𝒏𝒇𝒐
║┃💀┃ ➫ .𝒑𝒊𝒏𝒕𝒆𝒓𝒆𝒔𝒕
║┃💀┃ ➫ .𝒊𝒎𝒈`,

    tiktok: async (ctx) => {
        if (!ctx.text || !ctx.text.includes('tiktok.com')) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tiktok <tiktok-url>`, `${global.getPrefix()}tiktok https://vm.tiktok.com/xxxx`) });
        }
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Fetching TikTok video...") });

        try {
            const { data } = await axios.get('https://api.tiklydown.eu.org/api/download', {
                params: { url: ctx.text }, timeout: 30000
            });
            const video = data?.video?.noWatermark || data?.video?.no_watermark || data?.video?.watermark;
            if (!video) throw new Error('No downloadable video found in response');

            await ctx.bot.sendMessage(ctx.from, {
                video: { url: video },
                caption: `╔═════════════════╗\n║💀║ 🎵 𝑻𝒊𝒌𝑻𝒐𝒌\n╠═════════════════╣\n║💀║ 👤 ${data.author?.nickname || data.author?.name || 'Unknown'}\n║💀║ ❤️ ${data.stats?.likeCount ?? data.stats?.diggCount ?? 'N/A'}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Couldn't fetch that TikTok video (link may be private/expired): ${e.message}`) });
        }
    },

    ttmp3: async (ctx) => {
        if (!ctx.text || !ctx.text.includes('tiktok.com')) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}ttmp3 <tiktok-url>`) });
        }
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Extracting TikTok audio...") });

        try {
            const { data } = await axios.get('https://api.tiklydown.eu.org/api/download', {
                params: { url: ctx.text }, timeout: 30000
            });
            const music = data?.music?.playUrl || data?.music?.play_url || data?.music;
            if (!music || typeof music !== 'string') throw new Error('No audio track found');

            await ctx.bot.sendMessage(ctx.from, {
                audio: { url: music }, mimetype: 'audio/mpeg',
                caption: `🎵 ${data.music?.title || 'TikTok Audio'}`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Couldn't extract audio: ${e.message}`) });
        }
    },

    ytsearch: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}ytsearch <query>`, `${global.getPrefix()}ytsearch lofi hip hop`) });

        try {
            const { videos } = await yts(ctx.text);
            if (!videos?.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });

            const top = videos.slice(0, 8);
            let list = `╔═════════════════╗\n║💀║ 🔍 𝒀𝒐𝒖𝑻𝒖𝒃𝒆: ${ctx.text}\n╠═════════════════╣\n`;
            top.forEach((v, i) => {
                list += `║💀║ ${i + 1}. ${v.title}\n║💀║    ⏱️ ${v.timestamp} · 👁️ ${v.views.toLocaleString()}\n║💀║    🔗 ${v.url}\n`;
            });
            list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { image: { url: top[0].thumbnail }, caption: list }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Search failed: ${e.message}`) });
        }
    },

    ytinfo: async (ctx) => {
        if (!ctx.text || !(ctx.text.includes('youtube.com') || ctx.text.includes('youtu.be'))) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}ytinfo <youtube-url>`) });
        }
        try {
            const { data } = await axios.get('https://www.youtube.com/oembed', {
                params: { url: ctx.text, format: 'json' }, timeout: 20000
            });
            await ctx.bot.sendMessage(ctx.from, {
                image: { url: data.thumbnail_url },
                caption: `╔═════════════════╗\n║💀║ ▶️ ${data.title}\n╠═════════════════╣\n║💀║ 👤 ${data.author_name}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Couldn't fetch video info: ${e.message}`) });
        }
    },

    pinterest: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}pinterest <search term>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Pinterest requires an authenticated API key to search reliably. Use .img for free general image search instead.") });
    },

    img: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}img <search term>`) });

        if (!config.apis.pexels) {
            return ctx.bot.sendMessage(ctx.from, {
                text: global.styleInfo("Image search needs a free Pexels API key. Get one at https://www.pexels.com/api/ and add it as PEXELS_API_KEY in your .env file.")
            });
        }

        try {
            const { data } = await axios.get('https://api.pexels.com/v1/search', {
                params: { query: ctx.text, per_page: 1 },
                headers: { Authorization: config.apis.pexels },
                timeout: 20000
            });

            const photo = data?.photos?.[0];
            if (!photo) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No images found for that search.") });

            await ctx.bot.sendMessage(ctx.from, {
                image: { url: photo.src.large },
                caption: `╔═════════════════╗\n║💀║ 🖼️ ${ctx.text}\n╠═════════════════╣\n║💀║ 📷 ${photo.photographer}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Image search failed — try again in a moment.") });
        }
    }
};

// ================================================
// GROUP MANAGEMENT COMMANDS
// Developed by PrimeTech © 2026
// ================================================

function usage(cmd, example) {
    return `╔═════════════════╗
║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆
╠═════════════════╣
║💀║ ➫ ${cmd}
${example ? `║💀║ ➫ 𝑬𝒙: ${example}\n` : ''}╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

module.exports = {
    category: '𝑮𝑹𝑶𝑼𝑷 𝑪𝑴𝑫𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑮𝑹𝑶𝑼𝑷 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 ⚡
╠═════════════════╣
║ ✰〔〔 𝑮𝑹𝑶𝑼𝑷 𝑪𝑴𝑫𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒌𝒊𝒄𝒌 <@user>
║┃💀┃ ➫ ${p}𝒂𝒅𝒅 <number>
║┃💀┃ ➫ ${p}𝒑𝒓𝒐𝒎𝒐𝒕𝒆 <@user>
║┃💀┃ ➫ ${p}𝒅𝒆𝒎𝒐𝒕𝒆 <@user>
║┃💀┃ ➫ ${p}𝒕𝒂𝒈𝒂𝒍𝒍 <text>
║┃💀┃ ➫ ${p}𝒉𝒊𝒅𝒆𝒕𝒂𝒈 <text>
║┃💀┃ ➫ ${p}𝒐𝒑𝒆𝒏
║┃💀┃ ➫ ${p}𝒄𝒍𝒐𝒔𝒆
║┃💀┃ ➫ ${p}𝒊𝒏𝒇𝒐
║┃💀┃ ➫ ${p}𝒂𝒅𝒎𝒊𝒏𝒔
║┃💀┃ ➫ ${p}𝒍𝒊𝒏𝒌
║┃💀┃ ➫ ${p}𝒓𝒆𝒗𝒐𝒌𝒆
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒏𝒂𝒎𝒆 <text>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒅𝒆𝒔𝒄 <text>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒑𝒑 (reply image)
║┃💀┃ ➫ ${p}𝒘𝒆𝒍𝒄𝒐𝒎𝒆 <on/off>
║┃💀┃ ➫ ${p}𝒈𝒐𝒐𝒅𝒃𝒚𝒆 <on/off>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒘𝒆𝒍𝒄𝒐𝒎𝒆 <text>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒈𝒐𝒐𝒅𝒃𝒚𝒆 <text>
║┃💀┃ ➫ ${p}𝒈𝒆𝒕𝒃𝒊𝒐 <@user>
║┃💀┃ ➫ ${p}𝒈𝒆𝒕𝒑𝒑 <@user>
║┃💀┃ ➫ ${p}𝒓𝒆𝒒𝒖𝒆𝒔𝒕𝒔
║┃💀┃ ➫ ${p}𝒂𝒑𝒑𝒓𝒐𝒗𝒆
║┃💀┃ ➫ ${p}𝒓𝒆𝒋𝒆𝒄𝒕
║┃💀┃ ➫ ${p}𝒎𝒖𝒕𝒆
║┃💀┃ ➫ ${p}𝒖𝒏𝒎𝒖𝒕𝒆
║┃💀┃ ➫ ${p}𝒍𝒆𝒂𝒗𝒆 (owner only)
║┃💀┃ ➫ ${p}𝒋𝒐𝒊𝒏 <link> (owner only)
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭 ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒌𝒊𝒄𝒌
║┃💀┃ ➫ .𝒂𝒅𝒅
║┃💀┃ ➫ .𝒑𝒓𝒐𝒎𝒐𝒕𝒆
║┃💀┃ ➫ .𝒅𝒆𝒎𝒐𝒕𝒆
║┃💀┃ ➫ .𝒕𝒂𝒈𝒂𝒍𝒍
║┃💀┃ ➫ .𝒉𝒊𝒅𝒆𝒕𝒂𝒈
║┃💀┃ ➫ .𝒐𝒑𝒆𝒏
║┃💀┃ ➫ .𝒄𝒍𝒐𝒔𝒆
║┃💀┃ ➫ .𝒊𝒏𝒇𝒐
║┃💀┃ ➫ .𝒂𝒅𝒎𝒊𝒏𝒔
║┃💀┃ ➫ .𝒍𝒊𝒏𝒌
║┃💀┃ ➫ .𝒓𝒆𝒗𝒐𝒌𝒆
║┃💀┃ ➫ .𝒔𝒆𝒕𝒏𝒂𝒎𝒆
║┃💀┃ ➫ .𝒔𝒆𝒕𝒅𝒆𝒔𝒄
║┃💀┃ ➫ .𝒔𝒆𝒕𝒑𝒑
║┃💀┃ ➫ .𝒘𝒆𝒍𝒄𝒐𝒎𝒆
║┃💀┃ ➫ .𝒈𝒐𝒐𝒅𝒃𝒚𝒆
║┃💀┃ ➫ .𝒔𝒆𝒕𝒘𝒆𝒍𝒄𝒐𝒎𝒆
║┃💀┃ ➫ .𝒔𝒆𝒕𝒈𝒐𝒐𝒅𝒃𝒚𝒆
║┃💀┃ ➫ .𝒈𝒆𝒕𝒃𝒊𝒐
║┃💀┃ ➫ .𝒈𝒆𝒕𝒑𝒑
║┃💀┃ ➫ .𝒓𝒆𝒒𝒖𝒆𝒔𝒕𝒔
║┃💀┃ ➫ .𝒂𝒑𝒑𝒓𝒐𝒗𝒆
║┃💀┃ ➫ .𝒓𝒆𝒋𝒆𝒄𝒕
║┃💀┃ ➫ .𝒎𝒖𝒕𝒆
║┃💀┃ ➫ .𝒖𝒏𝒎𝒖𝒕𝒆
║┃💀┃ ➫ .𝒍𝒆𝒂𝒗𝒆
║┃💀┃ ➫ .𝒋𝒐𝒊𝒏`,

    // ============================================
    // MEMBER MANAGEMENT
    // ============================================

    kick: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}kick <@user>`, `${global.getPrefix()}kick @user or reply to their message`) });

        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'remove');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Removed @${target.split('@')[0]}`), mentions: [target] });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    add: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        const num = ctx.args[0]?.replace(/\D/g, '');
        if (!num) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}add <number>`, `${global.getPrefix()}add 923001234567`) });

        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Added ${num}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Couldn't add — they may have restricted who can add them: ${e.message}`) });
        }
    },

    promote: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}promote <@user>`) });

        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'promote');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Promoted @${target.split('@')[0]} to admin`), mentions: [target] });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    demote: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}demote <@user>`) });

        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'demote');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Demoted @${target.split('@')[0]}`), mentions: [target] });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // MESSAGING
    // ============================================

    tagall: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        const msg = ctx.text || '📢 Attention everyone';
        const mentions = ctx.participants.map(p => p.id);
        const list = ctx.participants.map(p => `@${p.id.split('@')[0]}`).join(' ');

        await ctx.bot.sendMessage(ctx.from, { text: `${msg}\n\n${list}`, mentions });
    },

    hidetag: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        const msg = ctx.text || ctx.m.quoted?.text || ' ';
        const mentions = ctx.participants.map(p => p.id);

        await ctx.bot.sendMessage(ctx.from, { text: msg, mentions });
    },

    // ============================================
    // GROUP SETTINGS
    // ============================================

    open: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'not_announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Group opened! Everyone can send messages.") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    close: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Group closed! Only admins can send messages.") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    mute: async (ctx) => module.exports.close(ctx),
    unmute: async (ctx) => module.exports.open(ctx),

    // ============================================
    // GROUP INFO
    // ============================================

    info: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });

        try {
            const group = await ctx.bot.groupMetadata(ctx.from);
            const admins = group.participants.filter(p => p.admin).length;
            const created = new Date(group.creation * 1000).toLocaleDateString();

            const info = `╔═════════════════╗
║💀║ 𝑮𝑹𝑶𝑼𝑷 𝑰𝑵𝑭𝑶
╠═════════════════╣
║💀║ 📛 𝑵𝒂𝒎𝒆: ${group.subject}
║💀║ 👥 𝑴𝒆𝒎𝒃𝒆𝒓𝒔: ${group.participants.length}
║💀║ 👑 𝑨𝒅𝒎𝒊𝒏𝒔: ${admins}
║💀║ 📅 𝑪𝒓𝒆𝒂𝒕𝒆𝒅: ${created}
║💀║ 🔐 𝑨𝒏𝒏𝒐𝒖𝒏𝒄𝒆-𝒐𝒏𝒍𝒚: ${group.announce ? 'Yes' : 'No'}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { text: info });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    admins: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });

        try {
            const group = await ctx.bot.groupMetadata(ctx.from);
            const admins = group.participants.filter(p => p.admin);

            let list = `╔═════════════════╗\n║💀║ 𝑨𝑫𝑴𝑰𝑵𝑺 𝑳𝑰𝑺𝑻 (${admins.length})\n╠═════════════════╣\n`;
            admins.forEach((a, i) => list += `║💀║ ${i + 1}. @${a.id.split('@')[0]}\n`);
            list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { text: list, mentions: admins.map(a => a.id) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    link: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        try {
            const code = await ctx.bot.groupInviteCode(ctx.from);
            await ctx.bot.sendMessage(ctx.from, { text: `╔═════════════════╗\n║💀║ 𝑮𝑹𝑶𝑼𝑷 𝑳𝑰𝑵𝑲\n╠═════════════════╣\n║💀║ 🔗 https://chat.whatsapp.com/${code}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    revoke: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            await ctx.bot.groupRevokeInvite(ctx.from);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Group link reset!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // GROUP UPDATE
    // ============================================

    setname: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setname <new name>`) });

        try {
            await ctx.bot.groupUpdateSubject(ctx.from, ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Name changed to: ${ctx.text}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    setdesc: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setdesc <new description>`) });

        try {
            await ctx.bot.groupUpdateDescription(ctx.from, ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Description updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    setpp: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        const imgMsg = ctx.m.message.imageMessage || ctx.m.quoted?.message?.imageMessage;
        if (!imgMsg) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setpp`, 'Send/reply to an image with .setpp') });

        try {
            const media = ctx.m.message.imageMessage ? await ctx.m.download() : await ctx.m.quoted.download();
            await ctx.bot.updateProfilePicture(ctx.from, media);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Group picture updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // WELCOME / GOODBYE
    // ============================================

    welcome: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        const state = ctx.args[0]?.toLowerCase();
        if (state !== 'on' && state !== 'off') return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}welcome <on/off>`) });

        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].welcome = state === 'on';
        if (state === 'on' && !global.db.groups[ctx.from].welcomeText) {
            global.db.groups[ctx.from].welcomeText = 'Welcome @user to @group! 🎉';
        }
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Welcome messages ${state === 'on' ? 'enabled' : 'disabled'}`) });
    },

    goodbye: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        const state = ctx.args[0]?.toLowerCase();
        if (state !== 'on' && state !== 'off') return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}goodbye <on/off>`) });

        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].goodbye = state === 'on';
        if (state === 'on' && !global.db.groups[ctx.from].goodbyeText) {
            global.db.groups[ctx.from].goodbyeText = 'Goodbye @user, we\'ll miss you 👋';
        }
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Goodbye messages ${state === 'on' ? 'enabled' : 'disabled'}`) });
    },

    setwelcome: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setwelcome <text>`, `${global.getPrefix()}setwelcome Welcome @user to @group!`) });

        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].welcomeText = ctx.text;
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Welcome message set!") });
    },

    setgoodbye: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setgoodbye <text>`, `${global.getPrefix()}setgoodbye Goodbye @user!`) });

        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].goodbyeText = ctx.text;
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Goodbye message set!") });
    },

    // ============================================
    // OWNER ONLY
    // ============================================

    leave: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });

        try {
            await ctx.bot.sendMessage(ctx.from, { text: "👋 Leaving group..." });
            await ctx.bot.groupLeave(ctx.from);
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    join: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}join <group-link>`) });

        try {
            const code = ctx.args[0].split('https://chat.whatsapp.com/')[1] || ctx.args[0];
            await ctx.bot.groupAcceptInvite(code);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Joined group!`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // USER INFO
    // ============================================

    getbio: async (ctx) => {
        const target = global.resolveTarget(ctx) || ctx.sender;
        try {
            const bio = await ctx.bot.fetchStatus(target);
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 𝑼𝑺𝑬𝑹 𝑩𝑰𝑶\n╠═════════════════╣\n║💀║ 👤 @${target.split('@')[0]}\n║💀║ 📝 ${bio.status || 'No bio set'}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`,
                mentions: [target]
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch bio") });
        }
    },

    getpp: async (ctx) => {
        const target = global.resolveTarget(ctx) || ctx.sender;
        try {
            const pp = await ctx.bot.profilePictureUrl(target, 'image');
            await ctx.bot.sendMessage(ctx.from, {
                image: { url: pp },
                caption: `╔═════════════════╗\n║💀║ 𝑷𝑹𝑶𝑭𝑰𝑳𝑬 𝑷𝑰𝑪𝑻𝑼𝑹𝑬\n╠═════════════════╣\n║💀║ 👤 @${target.split('@')[0]}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`,
                mentions: [target]
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("No profile picture found") });
        }
    },

    // ============================================
    // REQUEST MANAGEMENT
    // ============================================

    requests: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            if (!requests.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No pending requests") });

            let list = `╔═════════════════╗\n║💀║ 𝑷𝑬𝑵𝑫𝑰𝑵𝑮 𝑹𝑬𝑸𝑼𝑬𝑺𝑻𝑺 (${requests.length})\n╠═════════════════╣\n`;
            requests.forEach((req, i) => list += `║💀║ ${i + 1}. @${req.jid.split('@')[0]}\n`);
            list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { text: list, mentions: requests.map(r => r.jid) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    approve: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            if (!requests.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No pending requests") });
            
            for (const req of requests) {
                await ctx.bot.groupRequestParticipantsUpdate(ctx.from, [req.jid], 'approve');
                await global.sleep(500);
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Approved ${requests.length} requests`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    reject: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            if (!requests.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No pending requests") });
            
            for (const req of requests) {
                await ctx.bot.groupRequestParticipantsUpdate(ctx.from, [req.jid], 'reject');
                await global.sleep(500);
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Rejected ${requests.length} requests`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    }
};

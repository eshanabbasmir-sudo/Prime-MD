// ================================================
// BULK MEMBER ADD COMMANDS
// A single real implementation with different delay presets,
// since WhatsApp rate-limits how fast a bot can add members
// before numbers start getting rejected / flagged.
// ================================================

function usage(cmd, note) {
    return `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${cmd}\n${note ? `║💀║ ➫ ${note}\n` : ''}╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

async function bulkAdd(ctx, delayMs, label) {
    if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
    if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
    if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
    if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}${label.cmd} <numbers>`, `comma or space separated, e.g. 923001234567,923007654321`) });

    const numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
    const cleanNums = numbers.map(n => global.formatNumber(n)).filter(Boolean);
    if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers found!") });

    const etaSec = Math.ceil((cleanNums.length * delayMs) / 1000);
    await ctx.bot.sendMessage(ctx.from, {
        text: global.styleProcess(`${label.name}: adding ${cleanNums.length} member(s), ETA ~${global.formatTime(etaSec * 1000)}`)
    });

    let added = 0, failed = 0;
    for (let i = 0; i < cleanNums.length; i++) {
        try {
            const res = await ctx.bot.groupParticipantsUpdate(ctx.from, [cleanNums[i] + '@s.whatsapp.net'], 'add');
            if (res?.[0]?.status === '200' || res?.[0]?.status === 200 || !res?.[0]?.status) added++;
            else failed++;
        } catch (e) {
            failed++;
        }

        if ((i + 1) % 5 === 0 && i + 1 < cleanNums.length) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Progress: ${i + 1}/${cleanNums.length} (added ${added})`) });
        }
        if (i < cleanNums.length - 1) await global.sleep(delayMs);
    }

    await ctx.bot.sendMessage(ctx.from, {
        text: global.styleSuccess(`${label.name} complete — added ${added}/${cleanNums.length} (${failed} failed, likely due to their privacy settings)`)
    });
}

module.exports = {
    category: '𝑨𝑫𝑫 𝑪𝑴𝑫𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑩𝑼𝑳𝑲 𝑨𝑫𝑫 𝑪𝑶𝑴𝑴𝑨𝑵𝑫𝑺 ⚡
╠═════════════════╣
║ ✰〔〔 𝑨𝑫𝑫 𝑪𝑴𝑫𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}quickadd <nums> (3s delay)
║┃💀┃ ➫ ${p}safeadd <nums> (25s delay)
║┃💀┃ ➫ ${p}slowadd <nums> (60s delay)
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒒𝒖𝒊𝒄𝒌𝒂𝒅𝒅 (𝒇𝒂𝒔𝒕)
║┃💀┃ ➫ .𝒔𝒂𝒇𝒆𝒂𝒅𝒅 (𝒓𝒆𝒄𝒐𝒎𝒎𝒆𝒏𝒅𝒆𝒅)
║┃💀┃ ➫ .𝒔𝒍𝒐𝒘𝒂𝒅𝒅 (𝒔𝒂𝒇𝒆𝒔𝒕)`,

    quickadd: (ctx) => bulkAdd(ctx, 3000, { name: 'Quick Add', cmd: 'quickadd' }),
    safeadd: (ctx) => bulkAdd(ctx, 25000, { name: 'Safe Add', cmd: 'safeadd' }),
    slowadd: (ctx) => bulkAdd(ctx, 60000, { name: 'Slow Add', cmd: 'slowadd' })
};

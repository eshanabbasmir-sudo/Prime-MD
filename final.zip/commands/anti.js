// ================================================
// ANTI / GROUP PROTECTION COMMANDS
// Every toggle here is actually enforced in index.js
// (enforceGroupProtection / enforceAntiSpam) — nothing here
// is a "coming soon" stub.
// ================================================

function usage(cmd) {
    return `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${cmd} <𝒐𝒏/𝒐𝒇𝒇>\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

function makeToggle(key, label, cmdName) {
    return async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });

        const state = ctx.args[0]?.toLowerCase();
        if (state !== 'on' && state !== 'off') {
            const current = global.db.groups[ctx.from]?.[key] ? 'ON' : 'OFF';
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}${cmdName}`) + `\n(currently: ${current})` });
        }

        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from][key] = state === 'on';
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${label} ${state === 'on' ? 'enabled' : 'disabled'}`) });
    };
}

module.exports = {
    category: '𝑨𝑵𝑻𝑰 𝑪𝑴𝑫𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑨𝑵𝑻𝑰 𝑭𝑬𝑨𝑻𝑼𝑹𝑬𝑺 ⚡
╠═════════════════╣
║ ✰✰〔〔 𝑨𝑵𝑻𝑰 𝑴𝑬𝑵𝑼 〕 〕✰✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}antilink on/off (any link)
║┃💀┃ ➫ ${p}antilinkwa on/off (WA invite links)
║┃💀┃ ➫ ${p}antilinkyt on/off (YouTube links)
║┃💀┃ ➫ ${p}antilinktg on/off (Telegram links)
║┃💀┃ ➫ ${p}antilinkfb on/off (Facebook links)
║┃💀┃ ➫ ${p}antilinkkick on/off (kick on link)
║┃💀┃ ➫ ${p}antispam on/off (flood detection)
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌𝒘𝒂
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌𝒚𝒕
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌𝒕𝒈
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌𝒇𝒃
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒍𝒊𝒏𝒌𝒌𝒊𝒄𝒌
║┃💀┃ ➫ .𝒂𝒏𝒕𝒊𝒔𝒑𝒂𝒎`,

    antilink: makeToggle('antilink', 'Anti-link (all links)', 'antilink'),
    antilinkwa: makeToggle('antilinkwa', 'Anti-link (WhatsApp invites)', 'antilinkwa'),
    antilinkyt: makeToggle('antilinkyt', 'Anti-link (YouTube)', 'antilinkyt'),
    antilinktg: makeToggle('antilinktg', 'Anti-link (Telegram)', 'antilinktg'),
    antilinkfb: makeToggle('antilinkfb', 'Anti-link (Facebook)', 'antilinkfb'),
    antilinkkick: makeToggle('antilinkkick', 'Auto-kick on link post', 'antilinkkick'),
    antispam: makeToggle('antispam', 'Anti-spam flood detection', 'antispam')
};

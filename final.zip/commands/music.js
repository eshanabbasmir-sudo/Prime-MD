// ================================================
// MUSIC COMMANDS
// ================================================

const axios = require('axios');
const yts = require('yt-search');

function usage(cmd, note) {
    return `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${cmd}\n${note ? `║💀║ ➫ 𝑬𝒙: ${note}\n` : ''}╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

module.exports = {
    category: '𝑴𝑼𝑺𝑰𝑪',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑴𝑼𝑺𝑰𝑪 ⚡
╠═════════════════╣
║ ✰〔〔 𝑴𝑼𝑺𝑰𝑪 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}find <song name> (YouTube search)
║┃💀┃ ➫ ${p}lyrics <artist> - <title>
║┃💀┃ ➫ ${p}tts <text> (text-to-speech)
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒇𝒊𝒏𝒅 <𝒔𝒐𝒏𝒈>
║┃💀┃ ➫ .𝒍𝒚𝒓𝒊𝒄𝒔 <𝒂𝒓𝒕𝒊𝒔𝒕> - <𝒕𝒊𝒕𝒍𝒆>
║┃💀┃ ➫ .𝒕𝒕𝒔 <𝒕𝒆𝒙𝒕>`,

    find: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}find <song name>`, `${global.getPrefix()}find Alan Walker Faded`) });

        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching "${ctx.text}"...`) });

        try {
            const { videos } = await yts(ctx.text);
            if (!videos?.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });

            const top = videos.slice(0, 5);
            let list = `╔═════════════════╗\n║💀║ 🎵 𝑹𝒆𝒔𝒖𝒍𝒕𝒔 𝒇𝒐𝒓: ${ctx.text}\n╠═════════════════╣\n`;
            top.forEach((v, i) => list += `║💀║ ${i + 1}. ${v.title}\n║💀║    ⏱️ ${v.timestamp}\n║💀║    🔗 ${v.url}\n`);
            list += `╚═════════════════╝\n\n💡 Use ${global.getPrefix()}ytinfo <link> for details, or open the link directly to listen/download.\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { image: { url: top[0].thumbnail }, caption: list }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Search failed: ${e.message}`) });
        }
    },

    lyrics: async (ctx) => {
        if (!ctx.text || !ctx.text.includes('-')) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}lyrics <artist> - <title>`, `${global.getPrefix()}lyrics Ed Sheeran - Shape of You`) });

        const [artist, ...rest] = ctx.text.split('-');
        const title = rest.join('-').trim();
        if (!artist.trim() || !title) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Provide both artist and title, separated by -") });

        try {
            const { data } = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist.trim())}/${encodeURIComponent(title)}`, { timeout: 20000 });
            if (!data?.lyrics) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Lyrics not found for that song") });

            const trimmed = data.lyrics.length > 3500 ? data.lyrics.substring(0, 3500) + '\n...' : data.lyrics;
            await ctx.bot.sendMessage(ctx.from, { text: `╔═════════════════╗\n║💀║ 🎤 ${title} — ${artist.trim()}\n╠═════════════════╣\n${trimmed}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_` }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Lyrics not found for that song") });
        }
    },

    tts: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tts <text>`, `${global.getPrefix()}tts Hello there!`) });
        if (ctx.text.length > 200) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Keep text under 200 characters") });

        try {
            const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(ctx.text)}`;
            const buffer = await global.getBuffer(url, { Referer: 'https://translate.google.com/' });
            if (!buffer) throw new Error('TTS service unavailable');

            await ctx.bot.sendMessage(ctx.from, { audio: buffer, mimetype: 'audio/mpeg', ptt: true }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`TTS failed: ${e.message}`) });
        }
    }
};

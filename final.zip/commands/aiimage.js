// ================================================
// AI IMAGE GENERATION — free Pollinations.ai image API
// ================================================

const axios = require('axios');

async function generateImage(prompt, model = 'flux') {
    const encoded = encodeURIComponent(prompt);
    const url = `https://image.pollinations.ai/prompt/${encoded}`;
    const resp = await axios.get(url, {
        params: { model, width: 768, height: 768, nologo: true, seed: Math.floor(Math.random() * 999999) },
        responseType: 'arraybuffer',
        timeout: 60000
    });
    return Buffer.from(resp.data);
}

function makeImageCmd(label, cmdName, model) {
    return async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${global.getPrefix()}${cmdName} <𝒑𝒓𝒐𝒎𝒑𝒕>\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });

        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Generating ${label} image...`) });
        try {
            const imageBuffer = await generateImage(ctx.text, model);
            await ctx.bot.sendMessage(ctx.from, {
                image: imageBuffer,
                caption: `╔═════════════════╗\n║💀║ 🎨 ${label}\n╠═════════════════╣\n║💀║ ${ctx.text.substring(0, 60)}${ctx.text.length > 60 ? '...' : ''}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Image generation failed: ${e.message}`) });
        }
    };
}

module.exports = {
    category: '𝑨𝑰 𝑰𝑴𝑨𝑮𝑬',

    menu: (bot, from, pushName, logo) => {
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑨𝑰 𝑰𝑴𝑨𝑮𝑬 𝑮𝑬𝑵𝑬𝑹𝑨𝑻𝑰𝑶𝑵 ⚡
╠═════════════════╣
║ ✰〔〔 𝑨𝑰 𝑰𝑴𝑨𝑮𝑬 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${global.getPrefix()}imagine <𝒑𝒓𝒐𝒎𝒑𝒕>
║┃💀┃ ➫ ${global.getPrefix()}flux <𝒑𝒓𝒐𝒎𝒑𝒕>
║┃💀┃ ➫ ${global.getPrefix()}anime <𝒑𝒓𝒐𝒎𝒑𝒕>
║┃💀┃ ➫ ${global.getPrefix()}realistic <𝒑𝒓𝒐𝒎𝒑𝒕>
║┃💀┃ ➫ ${global.getPrefix()}3d <𝒑𝒓𝒐𝒎𝒑𝒕>
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒊𝒎𝒂𝒈𝒊𝒏𝒆
║┃💀┃ ➫ .𝒇𝒍𝒖𝒙
║┃💀┃ ➫ .𝒂𝒏𝒊𝒎𝒆
║┃💀┃ ➫ .𝒓𝒆𝒂𝒍𝒊𝒔𝒕𝒊𝒄
║┃💀┃ ➫ .3𝒅`,

    imagine: makeImageCmd('𝑨𝑰 𝑰𝒎𝒂𝒈𝒆', 'imagine', 'flux'),
    flux: makeImageCmd('𝑭𝒍𝒖𝒙', 'flux', 'flux'),
    anime: makeImageCmd('𝑨𝒏𝒊𝒎𝒆 𝑺𝒕𝒚𝒍𝒆', 'anime', 'flux'),
    realistic: makeImageCmd('𝑹𝒆𝒂𝒍𝒊𝒔𝒕𝒊𝒄', 'realistic', 'flux-realism'),
    threed: makeImageCmd('3𝑫 𝑺𝒕𝒚𝒍𝒆', '3d', 'flux-3d'),
    cartoon: makeImageCmd('𝑪𝒂𝒓𝒕𝒐𝒐𝒏', 'cartoon', 'flux'),
    ghibli: makeImageCmd('𝑮𝒉𝒊𝒃𝒍𝒊 𝑺𝒕𝒚𝒍𝒆', 'ghibli', 'flux'),
    cyberpunk: makeImageCmd('𝑪𝒚𝒃𝒆𝒓𝒑𝒖𝒏𝒌', 'cyberpunk', 'flux')
};

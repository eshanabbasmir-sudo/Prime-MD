// ================================================
// OWNER COMMANDS - Premium Bot Control
// Developed by PrimeTech © 2026
// ================================================

const config = require('../config');
const fs = require('fs-extra');
const { exec } = require('child_process');
const util = require('util');

// ================================================
// RESTRICTED OWNER NUMBERS (HARDCODED)
// Only these numbers can use dangerous commands
// ================================================
const RESTRICTED_OWNERS = ['923489801946', '923554503286'];

function isRestrictedOwner(sender) {
    const clean = sender.split('@')[0].replace(/[^0-9]/g, '');
    return RESTRICTED_OWNERS.includes(clean);
}

function usage(cmd, note) {
    return `╔═════════════════╗
║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆
╠═════════════════╣
║💀║ ➫ ${cmd}
${note ? `║💀║ ➫ 𝑬𝒙: ${note}\n` : ''}╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

module.exports = {
    category: '𝑶𝑾𝑵𝑬𝑹 𝑪𝑴𝑫𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑶𝑾𝑵𝑬𝑹 𝑪𝑶𝑴𝑴𝑨𝑵𝑫𝑺 ⚡
╠═════════════════╣
║ ✰〔〔 𝑩𝑶𝑻 𝑪𝑶𝑵𝑻𝑹𝑶𝑳 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒎𝒐𝒅𝒆 <public/private>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒑𝒓𝒆𝒇𝒊𝒙 <new prefix>
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒂𝒖𝒕𝒐𝒓𝒆𝒂𝒅 <on/off>
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑷𝑹𝑬𝑴𝑰𝑼𝑴 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒂𝒅𝒅𝒑𝒓𝒆𝒎 <@user>
║┃💀┃ ➫ ${p}𝒅𝒆𝒍𝒑𝒓𝒆𝒎 <@user>
║┃💀┃ ➫ ${p}𝒍𝒊𝒔𝒕𝒑𝒓𝒆𝒎
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑺𝑼𝑫𝑶 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒔𝒖𝒅𝒐 <@user>
║┃💀┃ ➫ ${p}𝒅𝒆𝒍𝒔𝒖𝒅𝒐 <@user>
║┃💀┃ ➫ ${p}𝒍𝒊𝒔𝒕𝒔𝒖𝒅𝒐
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑩𝑶𝑻 𝑷𝑹𝑶𝑭𝑰𝑳𝑬 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒑𝒑 (reply image)
║┃💀┃ ➫ ${p}𝒅𝒆𝒍𝒑𝒑
║┃💀┃ ➫ ${p}𝒔𝒆𝒕𝒃𝒊𝒐 <text>
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑫𝑨𝑻𝑨𝑩𝑨𝑺𝑬 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒈𝒆𝒕𝒅𝒃
║┃💀┃ ➫ ${p}𝒃𝒂𝒄𝒌𝒖𝒑
║┃💀┃ ➫ ${p}𝒓𝒆𝒔𝒕𝒐𝒓𝒆 (reply backup file)
║┃💀┃ ➫ ${p}𝒄𝒍𝒆𝒂𝒓𝒅𝒃 (clear all data)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑩𝑳𝑶𝑪𝑲 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒃𝒍𝒐𝒄𝒌 <@user>
║┃💀┃ ➫ ${p}𝒖𝒏𝒃𝒍𝒐𝒄𝒌 <@user>
║┃💀┃ ➫ ${p}𝒍𝒊𝒔𝒕𝒃𝒍𝒐𝒄𝒌
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑮𝑹𝑶𝑼𝑷 𝑴𝑨𝑵𝑨𝑮𝑬𝑴𝑬𝑵𝑻 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒋𝒐𝒊𝒏 <link>
║┃💀┃ ➫ ${p}𝒍𝒆𝒂𝒗𝒆
║┃💀┃ ➫ ${p}𝒈𝒄𝒍𝒆𝒂𝒏 (remove non-existent numbers)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑺𝑨𝑭𝑬𝑻𝒀 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒃𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕 <msg>
║┃💀┃ ➫ ${p}𝒂𝒏𝒏𝒐𝒖𝒏𝒄𝒆 <msg>
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑹𝑬𝑺𝑻𝑹𝑰𝑪𝑻𝑬𝑫 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒓𝒆𝒔𝒕𝒂𝒓𝒕
║┃💀┃ ➫ ${p}𝒔𝒉𝒖𝒕𝒅𝒐𝒘𝒏
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭 ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒎𝒐𝒅𝒆
║┃💀┃ ➫ .𝒔𝒆𝒕𝒑𝒓𝒆𝒇𝒊𝒙
║┃💀┃ ➫ .𝒔𝒆𝒕𝒂𝒖𝒕𝒐𝒓𝒆𝒂𝒅
║┃💀┃ ➫ .𝒂𝒅𝒅𝒑𝒓𝒆𝒎
║┃💀┃ ➫ .𝒅𝒆𝒍𝒑𝒓𝒆𝒎
║┃💀┃ ➫ .𝒍𝒊𝒔𝒕𝒑𝒓𝒆𝒎
║┃💀┃ ➫ .𝒔𝒖𝒅𝒐
║┃💀┃ ➫ .𝒅𝒆𝒍𝒔𝒖𝒅𝒐
║┃💀┃ ➫ .𝒍𝒊𝒔𝒕𝒔𝒖𝒅𝒐
║┃💀┃ ➫ .𝒔𝒆𝒕𝒑𝒑
║┃💀┃ ➫ .𝒅𝒆𝒍𝒑𝒑
║┃💀┃ ➫ .𝒔𝒆𝒕𝒃𝒊𝒐
║┃💀┃ ➫ .𝒈𝒆𝒕𝒅𝒃
║┃💀┃ ➫ .𝒃𝒂𝒄𝒌𝒖𝒑
║┃💀┃ ➫ .𝒓𝒆𝒔𝒕𝒐𝒓𝒆
║┃💀┃ ➫ .𝒄𝒍𝒆𝒂𝒓𝒅𝒃
║┃💀┃ ➫ .𝒃𝒍𝒐𝒄𝒌
║┃💀┃ ➫ .𝒖𝒏𝒃𝒍𝒐𝒄𝒌
║┃💀┃ ➫ .𝒍𝒊𝒔𝒕𝒃𝒍𝒐𝒄𝒌
║┃💀┃ ➫ .𝒋𝒐𝒊𝒏
║┃💀┃ ➫ .𝒍𝒆𝒂𝒗𝒆
║┃💀┃ ➫ .𝒈𝒄𝒍𝒆𝒂𝒏
║┃💀┃ ➫ .𝒃𝒓𝒐𝒂𝒅𝒄𝒂𝒔𝒕
║┃💀┃ ➫ .𝒂𝒏𝒏𝒐𝒖𝒏𝒄𝒆
║┃💀┃ ➫ .𝒓𝒆𝒔𝒕𝒂𝒓𝒕
║┃💀┃ ➫ .𝒔𝒉𝒖𝒕𝒅𝒐𝒘𝒏`,

    // ============================================
    // BOT CONTROL (Restricted)
    // ============================================

    mode: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const mode = ctx.args[0]?.toLowerCase();
        if (mode !== 'public' && mode !== 'private') return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}mode <public/private>`) + `\nCurrent: ${global.db.settings.public ? 'PUBLIC' : 'PRIVATE'}` });

        global.db.settings.public = mode === 'public';
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Mode changed to: ${mode.toUpperCase()}`) });
    },

    setprefix: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setprefix <new prefix>`) });

        global.db.settings.prefix = ctx.args[0];
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Prefix changed to: ${ctx.args[0]}`) });
    },

    setautoread: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const state = ctx.args[0]?.toLowerCase();
        if (state !== 'on' && state !== 'off') return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setautoread <on/off>`) + `\nCurrent: ${global.db.settings.autoread ? 'ON' : 'OFF'}` });

        global.db.settings.autoread = state === 'on';
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Auto-read ${state === 'on' ? 'enabled' : 'disabled'}`) });
    },

    // ============================================
    // RESTRICTED COMMANDS - Only for specific owners
    // ============================================

    restart: async (ctx) => {
        if (!isRestrictedOwner(ctx.sender)) {
            return ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError("⛔ This command is restricted to authorized owners only!") 
            });
        }
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("🔄 Restarting bot...") });
        global.saveDB();
        setTimeout(() => process.exit(0), 1000);
    },

    shutdown: async (ctx) => {
        if (!isRestrictedOwner(ctx.sender)) {
            return ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError("⛔ This command is restricted to authorized owners only!") 
            });
        }
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("🛑 Shutting down bot...") });
        global.saveDB();
        setTimeout(() => process.exit(0), 2000);
    },

    // ============================================
    // PREMIUM MANAGEMENT
    // ============================================

    addprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}addprem <number or @mention>`) });

        if (!global.db.premium.includes(target)) {
            global.db.premium.push(target);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Added premium: ${target.split('@')[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Already premium") });
        }
    },

    delprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}delprem <number or @mention>`) });

        const idx = global.db.premium.indexOf(target);
        if (idx > -1) {
            global.db.premium.splice(idx, 1);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`❌ Removed premium: ${target.split('@')[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("User not premium") });
        }
    },

    listprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        let list = `╔═════════════════╗\n║💀║ 𝑷𝑹𝑬𝑴𝑰𝑼𝑴 𝑼𝑺𝑬𝑹𝑺\n╠═════════════════╣\n`;
        if (global.db.premium.length) global.db.premium.forEach((id, i) => list += `║💀║ ${i + 1}. ${id.split('@')[0]}\n`);
        else list += `║💀║ ❌ 𝑵𝒐 𝒑𝒓𝒆𝒎𝒊𝒖𝒎 𝒖𝒔𝒆𝒓𝒔\n`;
        list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
        await ctx.bot.sendMessage(ctx.from, { text: list });
    },

    // ============================================
    // SUDO MANAGEMENT
    // ============================================

    sudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}sudo <number or @mention>`) });

        if (!global.db.sudo.includes(target)) {
            global.db.sudo.push(target);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Added sudo: ${target.split('@')[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Already sudo") });
        }
    },

    delsudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}delsudo <number or @mention>`) });

        const idx = global.db.sudo.indexOf(target);
        if (idx > -1) {
            global.db.sudo.splice(idx, 1);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`❌ Removed sudo: ${target.split('@')[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Not in sudo list") });
        }
    },

    listsudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        let list = `╔═════════════════╗\n║💀║ 𝑺𝑼𝑫𝑶 𝑼𝑺𝑬𝑹𝑺\n╠═════════════════╣\n`;
        if (global.db.sudo.length) global.db.sudo.forEach((id, i) => list += `║💀║ ${i + 1}. ${id.split('@')[0]}\n`);
        else list += `║💀║ ❌ 𝑵𝒐𝒏𝒆\n`;
        list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
        await ctx.bot.sendMessage(ctx.from, { text: list });
    },

    // ============================================
    // BOT PROFILE
    // ============================================

    setpp: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const imgMsg = ctx.m.message.imageMessage || ctx.m.quoted?.message?.imageMessage;
        if (!imgMsg) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setpp`, 'reply to an image') });

        try {
            const media = ctx.m.message.imageMessage ? await ctx.m.download() : await ctx.m.quoted.download();
            await ctx.bot.updateProfilePicture(ctx.bot.user.id, media);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Bot profile picture updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    delpp: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        try {
            await ctx.bot.removeProfilePicture(ctx.bot.user.id);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Bot profile picture removed!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    setbio: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}setbio <text>`) });

        try {
            await ctx.bot.updateProfileStatus(ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Bio updated to: ${ctx.text}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // DATABASE MANAGEMENT
    // ============================================

    getdb: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const dbFile = fs.readFileSync('./database/database.json');
        await ctx.bot.sendMessage(ctx.from, {
            document: dbFile, fileName: 'database.json', mimetype: 'application/json',
            caption: global.styleSuccess('📦 Database export')
        });
    },

    backup: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupPath = `./database/backup_${timestamp}.json`;
        fs.writeFileSync(backupPath, JSON.stringify(global.db, null, 2));
        const backupFile = fs.readFileSync(backupPath);
        await ctx.bot.sendMessage(ctx.from, {
            document: backupFile, fileName: `backup_${timestamp}.json`, mimetype: 'application/json',
            caption: global.styleSuccess(`💾 Database backup (${timestamp})`)
        });
        fs.unlinkSync(backupPath);
    },

    restore: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const docMsg = ctx.m.quoted?.message?.documentMessage;
        if (!docMsg) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}restore`, 'reply to a backup .json file') });

        try {
            const media = await ctx.m.quoted.download();
            const data = JSON.parse(media.toString());
            global.db = data;
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Database restored successfully!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    cleardb: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("⚠️ Clearing database...") });
        
        const settings = global.db.settings;
        const stats = global.db.stats;
        
        global.db = {
            users: {},
            groups: {},
            settings: settings,
            premium: [],
            sudo: [],
            stats: stats,
            customCommands: {}
        };
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("✅ Database cleared successfully!") });
    },

    // ============================================
    // BLOCK MANAGEMENT
    // ============================================

    block: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}block <number or @mention>`) });

        try {
            await ctx.bot.updateBlockStatus(target, 'block');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Blocked: ${target.split('@')[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    unblock: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const target = global.resolveTarget(ctx);
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}unblock <number or @mention>`) });

        try {
            await ctx.bot.updateBlockStatus(target, 'unblock');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Unblocked: ${target.split('@')[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    listblock: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        try {
            const blocklist = await ctx.bot.fetchBlocklist();
            let list = `╔═════════════════╗\n║💀║ 𝑩𝑳𝑶𝑪𝑲𝑬𝑫 𝑼𝑺𝑬𝑹𝑺\n╠═════════════════╣\n`;
            if (blocklist?.length) blocklist.forEach((id, i) => list += `║💀║ ${i + 1}. ${id.split('@')[0]}\n`);
            else list += `║💀║ ❌ 𝑵𝒐𝒏𝒆\n`;
            list += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
            await ctx.bot.sendMessage(ctx.from, { text: list });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // GROUP MANAGEMENT
    // ============================================

    join: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}join <group-link>`) });

        try {
            const code = ctx.args[0].split('https://chat.whatsapp.com/')[1] || ctx.args[0];
            await ctx.bot.groupAcceptInvite(code);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Joined group!`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    leave: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Use in a group to leave it") });

        try {
            await ctx.bot.sendMessage(ctx.from, { text: "👋 Goodbye!" });
            await ctx.bot.groupLeave(ctx.from);
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    gclean: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });

        try {
            const metadata = await ctx.bot.groupMetadata(ctx.from);
            let removed = 0;
            
            for (const participant of metadata.participants) {
                try {
                    await ctx.bot.profilePictureUrl(participant.id, 'image');
                } catch (e) {
                    try {
                        await ctx.bot.groupParticipantsUpdate(ctx.from, [participant.id], 'remove');
                        removed++;
                        await global.sleep(1000);
                    } catch (err) {}
                }
            }
            
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleSuccess(`✅ Removed ${removed} invalid/non-existent numbers`) 
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },

    // ============================================
    // BROADCAST
    // ============================================

    broadcast: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}broadcast <message>`) });

        const groups = Object.keys(global.db.groups);
        if (!groups.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No groups in database!") });

        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleProcess(`📤 Sending broadcast to ${groups.length} groups...`) 
        });

        let sent = 0, failed = 0;
        for (const group of groups) {
            try {
                await ctx.bot.sendMessage(group, { 
                    text: `📢 *BROADCAST*\n\n${ctx.text}\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_` 
                });
                sent++;
                await global.sleep(2000);
            } catch (e) {
                failed++;
            }
        }

        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(`✅ Broadcast sent to ${sent}/${groups.length} groups (${failed} failed)`) 
        });
    },

    announce: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}announce <message>`) });

        const users = Object.keys(global.db.users);
        if (!users.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No users in database!") });

        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleProcess(`📤 Sending announcement to ${users.length} users...`) 
        });

        let sent = 0, failed = 0;
        for (const user of users) {
            try {
                await ctx.bot.sendMessage(user, { 
                    text: `📢 *ANNOUNCEMENT*\n\n${ctx.text}\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_` 
                });
                sent++;
                await global.sleep(1500);
            } catch (e) {
                failed++;
            }
        }

        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(`✅ Announcement sent to ${sent}/${users.length} users (${failed} failed)`) 
        });
    }
};

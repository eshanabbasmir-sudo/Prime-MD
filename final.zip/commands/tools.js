// ================================================
// TOOLS — Premium Utility Commands
// Developed by PrimeTech © 2026
// ================================================

const axios = require('axios');
const config = require('../config');
const moment = require('moment-timezone');
const math = require('mathjs');

function usage(cmd, note) {
    return `╔═════════════════╗
║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆
╠═════════════════╣
║💀║ ➫ ${cmd}
${note ? `║💀║ ➫ 𝑬𝒙: ${note}\n` : ''}╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

function getMediaMessage(ctx) {
    return ctx.m.message.imageMessage || ctx.m.message.videoMessage || ctx.m.message.audioMessage ||
        ctx.m.message.documentMessage || ctx.m.quoted?.message?.imageMessage || ctx.m.quoted?.message?.videoMessage ||
        ctx.m.quoted?.message?.audioMessage || ctx.m.quoted?.message?.documentMessage;
}

async function downloadTargetMedia(ctx) {
    if (ctx.m.message.imageMessage || ctx.m.message.videoMessage || ctx.m.message.audioMessage || ctx.m.message.documentMessage) {
        return ctx.m.download();
    }
    if (ctx.m.quoted) return ctx.m.quoted.download();
    return null;
}

module.exports = {
    category: '𝑻𝑶𝑶𝑳𝑺',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑻𝑶𝑶𝑳𝑺 ⚡
╠═════════════════╣
║ ✰〔〔 𝑼𝑻𝑰𝑳𝑰𝑻𝑰𝑬𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒗𝒗 (reply view-once media)
║┃💀┃ ➫ ${p}𝒏𝒊𝒄𝒆 (secret save view-once)
║┃💀┃ ➫ ${p}𝒔𝒂𝒗𝒆 (reply media → save silently)
║┃💀┃ ➫ ${p}𝒔𝒊𝒎𝒅𝒂𝒕𝒂𝒃𝒂𝒔𝒆 <number>
║┃💀┃ ➫ ${p}𝒘𝒆𝒂𝒕𝒉𝒆𝒓 <city>
║┃💀┃ ➫ ${p}𝒄𝒖𝒓𝒓𝒆𝒏𝒄𝒚 <amt> <from> <to>
║┃💀┃ ➫ ${p}𝒄𝒂𝒍𝒄 <expression>
║┃💀┃ ➫ ${p}𝒘𝒊𝒌𝒊 <topic>
║┃💀┃ ➫ ${p}𝒅𝒆𝒇𝒊𝒏𝒆 <word>
║┃💀┃ ➫ ${p}𝒔𝒉𝒐𝒓𝒕𝒆𝒏 <url>
║┃💀┃ ➫ ${p}𝒒𝒓𝒄𝒐𝒅𝒆 <text>
║┃💀┃ ➫ ${p}𝒓𝒆𝒂𝒅𝒒𝒓 (reply image with QR)
║┃💀┃ ➫ ${p}𝒕𝒊𝒎𝒆 <timezone>
║┃💀┃ ➫ ${p}𝒔𝒕𝒂𝒕𝒔
║┃💀┃ ➫ ${p}𝒑𝒊𝒏𝒈
║┃💀┃ ➫ ${p}𝒓𝒖𝒏𝒕𝒊𝒎𝒆
║┃💀┃ ➫ ${p}𝒎𝒚𝒊𝒅
║┃💀┃ ➫ ${p}𝒈𝒓𝒐𝒖𝒑𝒊𝒅
║┃💀┃ ➫ ${p}𝒘𝒉𝒐𝒊𝒔 <@user>
║┃💀┃ ➫ ${p}𝒋𝒊𝒅 (reply → show sender's jid)
╠═════════════════╣
║ ✰〔〔 𝑻𝑬𝑿𝑻 & 𝑫𝑨𝑻𝑨 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒓𝒆𝒗𝒆𝒓𝒔𝒆 <text>
║┃💀┃ ➫ ${p}𝒄𝒐𝒖𝒏𝒕 <text>
║┃💀┃ ➫ ${p}𝒃𝒂𝒔𝒆𝟔𝟒𝒆𝒏𝒄𝒐𝒅𝒆 <text>
║┃💀┃ ➫ ${p}𝒃𝒂𝒔𝒆𝟔𝟒𝒅𝒆𝒄𝒐𝒅𝒆 <text>
║┃💀┃ ➫ ${p}𝒖𝒓𝒍𝒆𝒏𝒄𝒐𝒅𝒆 <text>
║┃💀┃ ➫ ${p}𝒖𝒓𝒍𝒅𝒆𝒄𝒐𝒅𝒆 <text>
║┃💀┃ ➫ ${p}𝒉𝒂𝒔𝒉 <text>
║┃💀┃ ➫ ${p}𝒑𝒂𝒔𝒔𝒘𝒐𝒓𝒅 <length>
║┃💀┃ ➫ ${p}𝒖𝒖𝒊𝒅
║┃💀┃ ➫ ${p}𝒄𝒐𝒍𝒐𝒓 <#hex>
╠═════════════════╣
║ ✰〔〔 𝑭𝑼𝑵 & 𝑹𝑨𝑵𝑫𝑶𝑴 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒒𝒖𝒐𝒕𝒆
║┃💀┃ ➫ ${p}𝒇𝒂𝒄𝒕
║┃💀┃ ➫ ${p}𝒋𝒐𝒌𝒆
║┃💀┃ ➫ ${p}𝒂𝒅𝒗𝒊𝒄𝒆
║┃💀┃ ➫ ${p}𝒅𝒊𝒄𝒆
║┃💀┃ ➫ ${p}𝒄𝒐𝒊𝒏𝒇𝒍𝒊𝒑
║┃💀┃ ➫ ${p}𝟖𝒃𝒂𝒍𝒍 <question>
║┃💀┃ ➫ ${p}𝒄𝒉𝒐𝒐𝒔𝒆 <opt1, opt2, ...>
╠═════════════════╣
║ ✰〔〔 𝑴𝑶𝑹𝑬 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒄𝒓𝒚𝒑𝒕𝒐 <symbol>
║┃💀┃ ➫ ${p}𝒓𝒂𝒏𝒅𝒐𝒎 <min> <max>
║┃💀┃ ➫ ${p}𝒆𝒎𝒐𝒋𝒊𝒇𝒚 <text>
║┃💀┃ ➫ ${p}𝒎𝒐𝒓𝒔𝒆 <text>
║┃💀┃ ➫ ${p}𝒅𝒆𝒎𝒐𝒓𝒔𝒆 <morse>
║┃💀┃ ➫ ${p}𝒄𝒂𝒕
║┃💀┃ ➫ ${p}𝒅𝒐𝒈
║┃💀┃ ➫ ${p}𝒅𝒂𝒕𝒆𝒅𝒊𝒇𝒇 <date1> <date2>
║┃💀┃ ➫ ${p}𝒇𝒊𝒍𝒆𝒔𝒊𝒛𝒆 <bytes>
║┃💀┃ ➫ ${p}𝒊𝒑
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭 ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒗𝒗 
║┃💀┃ ➫ .𝒏𝒊𝒄𝒆
║┃💀┃ ➫ .𝒔𝒂𝒗𝒆
║┃💀┃ ➫ .𝒔𝒊𝒎𝒅𝒂𝒕𝒂𝒃𝒂𝒔𝒆
║┃💀┃ ➫ .𝒘𝒆𝒂𝒕𝒉𝒆𝒓 
║┃💀┃ ➫ .𝒄𝒖𝒓𝒓𝒆𝒏𝒄𝒚
║┃💀┃ ➫ .𝒄𝒂𝒍𝒄
║┃💀┃ ➫ .𝒘𝒊𝒌𝒊
║┃💀┃ ➫ .𝒅𝒆𝒇𝒊𝒏𝒆
║┃💀┃ ➫ .𝒔𝒉𝒐𝒓𝒕𝒆𝒏
║┃💀┃ ➫ .𝒒𝒓𝒄𝒐𝒅𝒆 
║┃💀┃ ➫ .𝒓𝒆𝒂𝒅𝒒𝒓
║┃💀┃ ➫ .𝒕𝒊𝒎𝒆 
║┃💀┃ ➫ .𝒔𝒕𝒂𝒕𝒔 
║┃💀┃ ➫ .𝒑𝒊𝒏𝒈
║┃💀┃ ➫ .𝒓𝒖𝒏𝒕𝒊𝒎𝒆
║┃💀┃ ➫ .𝒎𝒚𝒊𝒅
║┃💀┃ ➫ .𝒈𝒓𝒐𝒖𝒑𝒊𝒅
║┃💀┃ ➫ .𝒘𝒉𝒐𝒊𝒔
║┃💀┃ ➫ .𝒋𝒊𝒅
║┃💀┃ ➫ .𝒓𝒆𝒗𝒆𝒓𝒔𝒆
║┃💀┃ ➫ .𝒄𝒐𝒖𝒏𝒕
║┃💀┃ ➫ .𝒃𝒂𝒔𝒆𝟔𝟒𝒆𝒏𝒄𝒐𝒅𝒆 
║┃💀┃ ➫ .𝒃𝒂𝒔𝒆𝟔𝟒𝒅𝒆𝒄𝒐𝒅𝒆
║┃💀┃ ➫ .𝒖𝒓𝒍𝒆𝒏𝒄𝒐𝒅𝒆
║┃💀┃ ➫ .𝒖𝒓𝒍𝒅𝒆𝒄𝒐𝒅𝒆
║┃💀┃ ➫ .𝒉𝒂𝒔𝒉 
║┃💀┃ ➫ .𝒑𝒂𝒔𝒔𝒘𝒐𝒓𝒅
║┃💀┃ ➫ .𝒖𝒖𝒊𝒅 
║┃💀┃ ➫ .𝒄𝒐𝒍𝒐𝒓
║┃💀┃ ➫ .𝒒𝒖𝒐𝒕𝒆 
║┃💀┃ ➫ .𝒇𝒂𝒄𝒕 
║┃💀┃ ➫ .𝒋𝒐𝒌𝒆
║┃💀┃ ➫ .𝒂𝒅𝒗𝒊𝒄𝒆
║┃💀┃ ➫ .𝒅𝒊𝒄𝒆
║┃💀┃ ➫ .𝒄𝒐𝒊𝒏𝒇𝒍𝒊𝒑
║┃💀┃ ➫ .8𝒃𝒂𝒍𝒍
║┃💀┃ ➫ .𝒄𝒉𝒐𝒐𝒔𝒆
║┃💀┃ ➫ .𝒄𝒓𝒚𝒑𝒕𝒐
║┃💀┃ ➫ .𝒓𝒂𝒏𝒅𝒐𝒎
║┃💀┃ ➫ .𝒆𝒎𝒐𝒋𝒊𝒇𝒚
║┃💀┃ ➫ .𝒎𝒐𝒓𝒔𝒆
║┃💀┃ ➫ .𝒅𝒆𝒎𝒐𝒓𝒔𝒆
║┃💀┃ ➫ .𝒄𝒂𝒕
║┃💀┃ ➫ .𝒅𝒐𝒈
║┃💀┃ ➫ .𝒅𝒂𝒕𝒆𝒅𝒊𝒇𝒇
║┃💀┃ ➫ .𝒇𝒊𝒍𝒆𝒔𝒊𝒛𝒆
║┃💀┃ ➫ .𝒊𝒑`,

// ================================================
// MEDIA / VIEW-ONCE
// ================================================

    vv: async (ctx) => {
        if (!ctx.m.quoted) {
            return ctx.bot.sendMessage(ctx.from, { 
                text: usage(`${global.getPrefix()}vv`, 'reply to a view-once photo/video with this command') 
            });
        }

        try {
            const media = await downloadTargetMedia(ctx);
            
            if (media) {
                const quotedType = ctx.m.quoted?.type;
                const isVideo = quotedType === 'videoMessage' || ctx.m.message?.videoMessage;
                const isAudio = quotedType === 'audioMessage' || ctx.m.message?.audioMessage;

                if (isVideo) {
                    await ctx.bot.sendMessage(ctx.from, { 
                        video: media, 
                        caption: global.styleSuccess('🎬 View-once video unlocked!') 
                    });
                } else if (isAudio) {
                    await ctx.bot.sendMessage(ctx.from, { 
                        audio: media, 
                        mimetype: 'audio/mpeg' 
                    });
                } else {
                    await ctx.bot.sendMessage(ctx.from, { 
                        image: media, 
                        caption: global.styleSuccess('📸 View-once image unlocked!') 
                    });
                }
                return;
            }
            
            const target = ctx.m.quoted;
            const msg = target.message;
            
            let mediaMsg = msg;
            let isViewOnce = false;
            
            if (msg?.viewOnceMessage) {
                mediaMsg = msg.viewOnceMessage.message;
                isViewOnce = true;
            } else if (msg?.viewOnceMessageV2) {
                mediaMsg = msg.viewOnceMessageV2.message;
                isViewOnce = true;
            } else if (msg?.viewOnceMessageV2Extension) {
                mediaMsg = msg.viewOnceMessageV2Extension.message;
                isViewOnce = true;
            }
            
            if (!isViewOnce) {
                return ctx.bot.sendMessage(ctx.from, { 
                    text: global.styleError("Reply to a view-once (disappearing) photo or video!") 
                });
            }
            
            const mediaBuffer = await ctx.bot.downloadMediaMessage({
                key: target.key,
                message: mediaMsg
            });
            
            if (!mediaBuffer) throw new Error('Could not download media');
            
            const msgType = Object.keys(mediaMsg)[0];
            if (msgType === 'videoMessage') {
                await ctx.bot.sendMessage(ctx.from, { 
                    video: mediaBuffer, 
                    caption: global.styleSuccess('🎬 View-once video unlocked!') 
                });
            } else {
                await ctx.bot.sendMessage(ctx.from, { 
                    image: mediaBuffer, 
                    caption: global.styleSuccess('📸 View-once image unlocked!') 
                });
            }
            
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError(`Failed: ${e.message}`) 
            });
        }
    },

    nice: async (ctx) => {
        if (!getMediaMessage(ctx) && !ctx.m.quoted?.isViewOnce) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}save`, '') });
        }
        try {
            const media = await downloadTargetMedia(ctx);
            if (!media) throw new Error('');

            const ownerJid = ctx.sender;

            if (ctx.m.quoted?.message?.videoMessage) {
                await ctx.bot.sendMessage(ownerJid, { video: media, caption: '💾 Saved media' });
            } else if (ctx.m.quoted?.message?.audioMessage) {
                await ctx.bot.sendMessage(ownerJid, { audio: media, mimetype: 'audio/mpeg' });
            } else {
                await ctx.bot.sendMessage(ownerJid, { image: media, caption: '💾 Saved media secretly💀' });
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess('👍') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Save failed: ${e.message}`) });
        }
    },

    save: async (ctx) => {
        if (!getMediaMessage(ctx) && !ctx.m.quoted?.isViewOnce) {
            return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}save`, 'reply to any image/video/audio to have it sent to your own DM') });
        }
        try {
            const media = await downloadTargetMedia(ctx);
            if (!media) throw new Error('Could not download media');

            const ownerJid = ctx.sender;

            if (ctx.m.quoted?.message?.videoMessage) {
                await ctx.bot.sendMessage(ownerJid, { video: media, caption: '💾 Saved media' });
            } else if (ctx.m.quoted?.message?.audioMessage) {
                await ctx.bot.sendMessage(ownerJid, { audio: media, mimetype: 'audio/mpeg' });
            } else {
                await ctx.bot.sendMessage(ownerJid, { image: media, caption: '💾 Saved media' });
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess('Sent to your DM') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Save failed: ${e.message}`) });
        }
    },

    // ============================================
    // SIM DATABASE LOOKUP
    // ============================================

    simdatabase: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}simdatabase <number>`, `${global.getPrefix()}simdatabase 03555555555`) 
        });

        const number = ctx.text.replace(/\D/g, '');
        if (number.length < 10) return ctx.bot.sendMessage(ctx.from, { 
            text: global.styleError("Invalid number! Must be at least 10 digits.") 
        });

        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleProcess(`Fetching SIM database for ${number}...`) 
        });

        try {
            let data = null;

            try {
                const response = await axios.get(`https://paksimsdata.pro/api3.php?number=${number}`, { 
                    timeout: 15000 
                });
                data = response.data;
            } catch (e) {
                try {
                    const response = await axios.get(`https://rapidid.af7u76.workers.dev/?number=${number}`, { 
                        timeout: 15000 
                    });
                    data = response.data;
                } catch (e2) {
                    throw new Error('Service temporarily unavailable');
                }
            }

            if (!data) throw new Error('No data received');

            if (data.Error) {
                return ctx.bot.sendMessage(ctx.from, { 
                    text: global.styleError(`❌ ${data.Error}`) 
                });
            }

            let resultText = `╔══════════════════════════════╗\n`;
            resultText += `║💀║ 📱 SIM DATABASE RESULTS\n`;
            resultText += `╠══════════════════════════════╣\n`;
            resultText += `║💀║ Number: ${number}\n`;
            
            if (typeof data === 'object') {
                for (const [key, value] of Object.entries(data)) {
                    if (key !== 'Error' && value) {
                        resultText += `║💀║ ${key}: ${value}\n`;
                    }
                }
            } else if (typeof data === 'string') {
                resultText += `║💀║ ${data}\n`;
            }

            resultText += `╚══════════════════════════════╝\n\n`;
            resultText += `> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

            await ctx.bot.sendMessage(ctx.from, { text: resultText }, { quoted: ctx.m });

        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError(`SIM database lookup failed: ${e.message}`) 
            });
        }
    },

    // ============================================
    // GENERAL UTILITIES
    // ============================================

    weather: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}weather <city>`, `${global.getPrefix()}weather London`) });
        try {
            const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(ctx.text)}`, { params: { format: 'j1' }, timeout: 20000 });
            const cur = data.current_condition[0];
            const area = data.nearest_area[0];
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 🌤️ 𝑾𝒆𝒂𝒕𝒉𝒆𝒓: ${area.areaName[0].value}, ${area.country[0].value}\n╠═════════════════╣\n║💀║ 🌡️ ${cur.temp_C}°C (feels ${cur.FeelsLikeC}°C)\n║💀║ ☁️ ${cur.weatherDesc[0].value}\n║💀║ 💧 Humidity: ${cur.humidity}%\n║💀║ 💨 Wind: ${cur.windspeedKmph} km/h\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch weather for that location") });
        }
    },

    currency: async (ctx) => {
        const parts = ctx.args;
        if (parts.length < 3) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}currency <amount> <from> <to>`, `${global.getPrefix()}currency 100 USD EUR`) });
        const [amountStr, from, to] = parts;
        const amount = parseFloat(amountStr);
        if (isNaN(amount)) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Invalid amount") });
        try {
            const { data } = await axios.get(`https://api.exchangerate-api.com/v4/latest/${from.toUpperCase()}`, { timeout: 20000 });
            const rate = data.rates[to.toUpperCase()];
            if (!rate) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Unknown currency code") });
            const result = (amount * rate).toFixed(2);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${amount} ${from.toUpperCase()} = ${result} ${to.toUpperCase()}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Currency conversion failed") });
        }
    },

    calc: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}calc <expression>`, `${global.getPrefix()}calc (5+3)*2`) });
        try {
            const result = math.evaluate(ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${ctx.text} = ${result}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Invalid expression") });
        }
    },

    wiki: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}wiki <topic>`) });
        try {
            const { data } = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(ctx.text)}`, { timeout: 20000 });
            if (!data.extract) throw new Error('no summary');
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 📖 ${data.title}\n╠═════════════════╣\n${data.extract}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No Wikipedia article found for that topic") });
        }
    },

    define: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}define <word>`) });
        try {
            const { data } = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(ctx.text)}`, { timeout: 20000 });
            const entry = data[0];
            const meaning = entry.meanings[0];
            const def = meaning.definitions[0];
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 📚 ${entry.word} (${meaning.partOfSpeech})\n╠═════════════════╣\n║💀║ ${def.definition}\n${def.example ? `║💀║ 💬 "${def.example}"\n` : ''}╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No definition found for that word") });
        }
    },

    shorten: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}shorten <url>`) });
        try {
            const { data } = await axios.get(`https://tinyurl.com/api-create.php`, { params: { url: ctx.text }, timeout: 20000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(data) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't shorten that URL") });
        }
    },

    qrcode: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}qrcode <text>`) });
        try {
            const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(ctx.text)}`;
            const buffer = await global.getBuffer(url);
            if (!buffer) throw new Error('QR generation failed');
            await ctx.bot.sendMessage(ctx.from, { image: buffer, caption: global.styleSuccess('QR code generated') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't generate QR code") });
        }
    },

    readqr: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}readqr`, 'reply to an image containing a QR code') });
        try {
            const media = await downloadTargetMedia(ctx);
            const FormData = require('form-data');
            const form = new FormData();
            form.append('file', media, 'qr.png');
            const { data } = await axios.post('https://api.qrserver.com/v1/read-qr-code/', form, { headers: form.getHeaders(), timeout: 20000 });
            const text = data?.[0]?.symbol?.[0]?.data;
            if (!text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No QR code detected in that image") });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`QR content: ${text}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't read QR code from that image") });
        }
    },

    time: async (ctx) => {
        const tz = ctx.text || 'UTC';
        try {
            const now = moment().tz(tz);
            if (!now.isValid()) throw new Error('invalid timezone');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${tz}: ${now.format('YYYY-MM-DD HH:mm:ss')}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Unknown timezone. Example: Asia/Karachi, America/New_York") });
        }
    },

    stats: async (ctx) => {
        const uptime = global.formatTime(Date.now() - global.db.stats.startTime);
        await ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ 📊 𝑩𝑶𝑻 𝑺𝑻𝑨𝑻𝑺\n╠═════════════════╣\n║💀║ ⏱️ 𝑼𝒑𝒕𝒊𝒎𝒆: ${uptime}\n║💀║ 📨 𝑪𝒐𝒎𝒎𝒂𝒏𝒅𝒔 𝒓𝒖𝒏: ${global.db.stats.commands}\n║💀║ 👥 𝑮𝒓𝒐𝒖𝒑𝒔 𝒕𝒓𝒂𝒄𝒌𝒆𝒅: ${Object.keys(global.db.groups).length}\n║💀║ ⭐ 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝒖𝒔𝒆𝒓𝒔: ${global.db.premium.length}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        });
    },

    ping: async (ctx) => {
        const start = Date.now();
        await ctx.bot.sendMessage(ctx.from, { text: '🏓' });
        const ping = Date.now() - start;
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Pong! ${ping}ms`) });
    },

    runtime: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Uptime: ${global.formatTime(Date.now() - global.db.stats.startTime)}`) });
    },

    myid: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Your ID: ${ctx.sender.split('@')[0]}`) });
    },

    groupid: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Group ID: ${ctx.from}`) });
    },

    whois: async (ctx) => {
        const target = global.resolveTarget(ctx) || ctx.sender;
        try {
            const [status, ppUrl] = await Promise.allSettled([
                ctx.bot.fetchStatus(target),
                ctx.bot.profilePictureUrl(target, 'image')
            ]);
            const bio = status.status === 'fulfilled' ? (status.value.status || 'No bio') : 'No bio';
            const caption = `╔═════════════════╗\n║💀║ 👤 @${target.split('@')[0]}\n╠═════════════════╣\n║💀║ 📝 ${bio}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
            if (ppUrl.status === 'fulfilled') {
                await ctx.bot.sendMessage(ctx.from, { image: { url: ppUrl.value }, caption, mentions: [target] });
            } else {
                await ctx.bot.sendMessage(ctx.from, { text: caption, mentions: [target] });
            }
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch that user's info") });
        }
    },

    jid: async (ctx) => {
        const target = ctx.m.quoted?.sender || ctx.sender;
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`JID: ${target}`) });
    },

    // ============================================
    // TEXT & DATA UTILITIES
    // ============================================

    reverse: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}reverse <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(ctx.text.split('').reverse().join('')) }, { quoted: ctx.m });
    },

    count: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}count <text>`) });
        const chars = ctx.text.length;
        const words = ctx.text.trim().split(/\s+/).filter(Boolean).length;
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Characters: ${chars} | Words: ${words}`) }, { quoted: ctx.m });
    },

    base64encode: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}base64encode <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(Buffer.from(ctx.text).toString('base64')) }, { quoted: ctx.m });
    },

    base64decode: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}base64decode <text>`) });
        try {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(Buffer.from(ctx.text, 'base64').toString('utf-8')) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Invalid base64 string") });
        }
    },

    urlencode: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}urlencode <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(encodeURIComponent(ctx.text)) }, { quoted: ctx.m });
    },

    urldecode: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}urldecode <text>`) });
        try {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(decodeURIComponent(ctx.text)) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Invalid encoded string") });
        }
    },

    hash: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}hash <text>`) });
        const crypto = require('crypto');
        const md5 = crypto.createHash('md5').update(ctx.text).digest('hex');
        const sha1 = crypto.createHash('sha1').update(ctx.text).digest('hex');
        const sha256 = crypto.createHash('sha256').update(ctx.text).digest('hex');
        await ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ 🔐 𝑯𝒂𝒔𝒉𝒆𝒔\n╠═════════════════╣\n║💀║ MD5: ${md5}\n║💀║ SHA1: ${sha1}\n║💀║ SHA256: ${sha256}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });
    },

    password: async (ctx) => {
        const len = Math.min(Math.max(parseInt(ctx.text) || 16, 4), 64);
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let pass = '';
        for (let i = 0; i < len; i++) pass += chars[Math.floor(Math.random() * chars.length)];
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(pass) }, { quoted: ctx.m });
    },

    uuid: async (ctx) => {
        const crypto = require('crypto');
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(crypto.randomUUID()) }, { quoted: ctx.m });
    },

    color: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}color <#hex>`, `${global.getPrefix()}color #ff5733`) });
        try {
            const hex = ctx.text.replace('#', '');
            const url = `https://singlecolorimage.com/get/${hex}/400x400`;
            const buffer = await global.getBuffer(url);
            if (!buffer) throw new Error('Invalid color');
            await ctx.bot.sendMessage(ctx.from, { image: buffer, caption: global.styleSuccess(`#${hex}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Invalid color — use a hex code like #ff5733") });
        }
    },

    // ============================================
    // FUN / RANDOM
    // ============================================

    quote: async (ctx) => {
        try {
            const { data } = await axios.get('https://api.quotable.io/random', { timeout: 20000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`"${data.content}" — ${data.author}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch a quote right now") });
        }
    },

    fact: async (ctx) => {
        try {
            const { data } = await axios.get('https://uselessfacts.jsph.pl/api/v2/facts/random', { timeout: 20000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(data.text) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch a fact right now") });
        }
    },

    joke: async (ctx) => {
        try {
            const { data } = await axios.get('https://official-joke-api.appspot.com/random_joke', { timeout: 20000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${data.setup}\n\n${data.punchline}`) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch a joke right now") });
        }
    },

    advice: async (ctx) => {
        try {
            const { data } = await axios.get('https://api.adviceslip.com/advice', { timeout: 20000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(data.slip.advice) }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch advice right now") });
        }
    },

    dice: async (ctx) => {
        const roll = Math.floor(Math.random() * 6) + 1;
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`🎲 You rolled a ${roll}`) }, { quoted: ctx.m });
    },

    coinflip: async (ctx) => {
        const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`🪙 ${result}`) }, { quoted: ctx.m });
    },

    '8ball': async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}8ball <question>`) });
        const answers = ['Yes, definitely.', 'No.', 'Maybe.', 'Ask again later.', 'Absolutely!', 'It is unlikely.', 'Without a doubt.', 'Cannot predict now.'];
        const answer = answers[Math.floor(Math.random() * answers.length)];
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`🎱 ${answer}`) }, { quoted: ctx.m });
    },

    choose: async (ctx) => {
        if (!ctx.text || !ctx.text.includes(',')) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}choose <opt1, opt2, ...>`, `${global.getPrefix()}choose pizza, burger, sushi`) });
        const options = ctx.text.split(',').map(o => o.trim()).filter(Boolean);
        const choice = options[Math.floor(Math.random() * options.length)];
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`I choose: ${choice}`) }, { quoted: ctx.m });
    },

    // ============================================
    // CRYPTO PRICE CHECKER
    // ============================================

    crypto: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}crypto <symbol>`, `${global.getPrefix()}crypto bitcoin`) 
        });
        
        try {
            const symbol = ctx.text.toLowerCase().trim();
            const { data } = await axios.get(`https://api.coingecko.com/api/v3/simple/price`, {
                params: { ids: symbol, vs_currencies: 'usd,eur,gbp' },
                timeout: 15000
            });
            
            if (!data[symbol]) return ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError(`Unknown crypto: ${symbol}`) 
            });
            
            const prices = data[symbol];
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 💰 ${symbol.toUpperCase()} Price\n╠═════════════════╣\n║💀║ 💵 USD: $${prices.usd || 'N/A'}\n║💀║ 💶 EUR: €${prices.eur || 'N/A'}\n║💀║ 💷 GBP: £${prices.gbp || 'N/A'}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError(`Crypto lookup failed: ${e.message}`) 
            });
        }
    },

    // ============================================
    // RANDOM NUMBER GENERATOR
    // ============================================

    random: async (ctx) => {
        const parts = ctx.text?.split(' ') || [];
        if (parts.length < 2) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}random <min> <max>`, `${global.getPrefix()}random 1 100`) 
        });
        
        const min = parseInt(parts[0]);
        const max = parseInt(parts[1]);
        if (isNaN(min) || isNaN(max) || min >= max) return ctx.bot.sendMessage(ctx.from, { 
            text: global.styleError("Invalid range! Min must be less than max.") 
        });
        
        const result = Math.floor(Math.random() * (max - min + 1)) + min;
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(`🎲 Random number between ${min} and ${max}: ${result}`) 
        }, { quoted: ctx.m });
    },

    // ============================================
    // EMOJIFY TEXT
    // ============================================

    emojify: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}emojify <text>`, `${global.getPrefix()}emojify hello`) 
        });

        const emojiMap = {
            'a': '🅰️', 'b': '🅱️', 'c': '🇨', 'd': '🇩', 'e': '🇪',
            'f': '🇫', 'g': '🇬', 'h': '🇭', 'i': '🇮', 'j': '🇯',
            'k': '🇰', 'l': '🇱', 'm': '🇲', 'n': '🇳', 'o': '🅾️',
            'p': '🇵', 'q': '🇶', 'r': '🇷', 's': '🇸', 't': '🇹',
            'u': '🇺', 'v': '🇻', 'w': '🇼', 'x': '🇽', 'y': '🇾', 'z': '🇿',
            '0': '0️⃣', '1': '1️⃣', '2': '2️⃣', '3': '3️⃣', '4': '4️⃣',
            '5': '5️⃣', '6': '6️⃣', '7': '7️⃣', '8': '8️⃣', '9': '9️⃣',
            '!': '❗', '?': '❓', '#': '#️⃣', '*': '*️⃣'
        };

        const result = ctx.text.toLowerCase().split('').map(char => emojiMap[char] || char).join('');
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(result) 
        }, { quoted: ctx.m });
    },

    // ============================================
    // TEXT TO MORSE CODE
    // ============================================

    morse: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}morse <text>`, `${global.getPrefix()}morse hello`) 
        });

        const morseMap = {
            'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.',
            'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---',
            'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---',
            'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-',
            'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--',
            'z': '--..', '0': '-----', '1': '.----', '2': '..---',
            '3': '...--', '4': '....-', '5': '.....', '6': '-....',
            '7': '--...', '8': '---..', '9': '----.', ' ': '/'
        };

        const result = ctx.text.toLowerCase().split('').map(char => morseMap[char] || char).join(' ');
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(result) 
        }, { quoted: ctx.m });
    },

    // ============================================
    // MORSE CODE TO TEXT
    // ============================================

    demorse: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}demorse <morse>`, `${global.getPrefix()}demorse .... . .-.. .-.. ---`) 
        });

        const morseMap = {
            '.-': 'a', '-...': 'b', '-.-.': 'c', '-..': 'd', '.': 'e',
            '..-.': 'f', '--.': 'g', '....': 'h', '..': 'i', '.---': 'j',
            '-.-': 'k', '.-..': 'l', '--': 'm', '-.': 'n', '---': 'o',
            '.--.': 'p', '--.-': 'q', '.-.': 'r', '...': 's', '-': 't',
            '..-': 'u', '...-': 'v', '.--': 'w', '-..-': 'x', '-.--': 'y',
            '--..': 'z', '-----': '0', '.----': '1', '..---': '2',
            '...--': '3', '....-': '4', '.....': '5', '-....': '6',
            '--...': '7', '---..': '8', '----.': '9', '/': ' '
        };

        const result = ctx.text.split(' ').map(code => morseMap[code] || code).join('');
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(result) 
        }, { quoted: ctx.m });
    },

    // ============================================
    // RANDOM CAT IMAGE
    // ============================================

    cat: async (ctx) => {
        try {
            const { data } = await axios.get('https://api.thecatapi.com/v1/images/search', { timeout: 10000 });
            if (!data?.[0]?.url) throw new Error('No cat found');
            await ctx.bot.sendMessage(ctx.from, { 
                image: { url: data[0].url }, 
                caption: global.styleSuccess('🐱 Here\'s a random cat!') 
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError("Couldn't fetch a cat right now") 
            });
        }
    },

    // ============================================
    // RANDOM DOG IMAGE
    // ============================================

    dog: async (ctx) => {
        try {
            const { data } = await axios.get('https://dog.ceo/api/breeds/image/random', { timeout: 10000 });
            if (!data?.message) throw new Error('No dog found');
            await ctx.bot.sendMessage(ctx.from, { 
                image: { url: data.message }, 
                caption: global.styleSuccess('🐶 Here\'s a random dog!') 
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError("Couldn't fetch a dog right now") 
            });
        }
    },

    // ============================================
    // DATE DIFFERENCE CALCULATOR
    // ============================================

    datediff: async (ctx) => {
        const parts = ctx.text?.split(' ') || [];
        if (parts.length < 2) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}datediff <date1> <date2>`, `${global.getPrefix()}datediff 2024-01-01 2024-12-31`) 
        });

        const date1 = new Date(parts[0]);
        const date2 = new Date(parts[1]);

        if (isNaN(date1.getTime()) || isNaN(date2.getTime())) {
            return ctx.bot.sendMessage(ctx.from, { 
                text: global.styleError("Invalid date format! Use YYYY-MM-DD") 
            });
        }

        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const diffWeeks = Math.floor(diffDays / 7);
        const diffMonths = Math.floor(diffDays / 30);
        const diffYears = Math.floor(diffDays / 365);

        await ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ 📅 Date Difference\n╠═════════════════╣\n║💀║ 📆 ${parts[0]} → ${parts[1]}\n║💀║ 📅 ${diffDays} days\n║💀║ 📅 ${diffWeeks} weeks\n║💀║ 📅 ${diffMonths} months (approx)\n║💀║ 📅 ${diffYears} years (approx)\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });
    },

    // ============================================
    // FILE SIZE CONVERTER
    // ============================================

    filesize: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { 
            text: usage(`${global.getPrefix()}filesize <bytes>`, `${global.getPrefix()}filesize 1048576`) 
        });

        const bytes = parseInt(ctx.text);
        if (isNaN(bytes) || bytes < 0) return ctx.bot.sendMessage(ctx.from, { 
            text: global.styleError("Invalid number!") 
        });

        const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        let size = bytes;
        let unitIndex = 0;
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }

        await ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ 📦 File Size\n╠═════════════════╣\n║💀║ Bytes: ${bytes.toLocaleString()} B\n║💀║ ${units[unitIndex]}: ${size.toFixed(2)} ${units[unitIndex]}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });
    },

    // ============================================
    // IP INFORMATION
    // ============================================

    ip: async (ctx) => {
        try {
            let target = ctx.text?.trim();
            if (!target) {
                const { data } = await axios.get('https://api.ipify.org?format=json', { timeout: 10000 });
                target = data.ip;
            }

            const { data: info } = await axios.get(`https://ip-api.com/json/${encodeURIComponent(target)}`, { timeout: 10000 });
            if (info.status === 'fail') throw new Error(info.message || 'Invalid IP or domain');

            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 🌐 IP Information\n╠═════════════════╣\n║💀║ 📍 IP: ${info.query}\n║💀║ 🌍 Country: ${info.country || 'N/A'}\n║💀║ 🏙️ City: ${info.city || 'N/A'}\n║💀║ 📡 ISP: ${info.isp || 'N/A'}\n║💀║ 📮 Region: ${info.regionName || 'N/A'}\n║💀║ 🌐 Timezone: ${info.timezone || 'N/A'}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, {
                text: global.styleError(`Couldn't fetch IP information: ${e.message}`)
            });
        }
    }
};

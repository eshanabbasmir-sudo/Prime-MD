// ================================================
// CONVERTER COMMANDS - Media & Text Conversion
// Developed by PrimeTech © 2026
// ================================================

const fs = require('fs-extra');
const ffmpeg = require('fluent-ffmpeg');
const { Jimp, JimpMime } = require('jimp');
const AdmZip = require('adm-zip');
const axios = require('axios');
const FormData = require('form-data');

function usage(cmd, note) {
    return `╔═════════════════╗
║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆
╠═════════════════╣
║💀║ ➫ ${cmd}
${note ? `║💀║ ➫ 𝑬𝒙: ${note}\n` : ''}╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
}

function getMediaMessage(ctx) {
    return ctx.m.message.imageMessage || ctx.m.message.videoMessage || ctx.m.message.audioMessage ||
        ctx.m.message.documentMessage || ctx.m.quoted?.message?.imageMessage || ctx.m.quoted?.message?.videoMessage ||
        ctx.m.quoted?.message?.audioMessage || ctx.m.quoted?.message?.documentMessage;
}

async function downloadTargetMedia(ctx) {
    if (ctx.m.message.imageMessage || ctx.m.message.videoMessage || ctx.m.message.audioMessage || ctx.m.message.documentMessage) {
        return ctx.m.download();
    }
    if (ctx.m.quoted) return ctx.m.quoted.download();
    return null;
}

// Convert an image buffer to webp via ffmpeg
function imageToWebp(inputBuffer, opts = {}) {
    return new Promise(async (resolve, reject) => {
        const inputPath = `./tmp/in_${Date.now()}.png`;
        const outputPath = `./tmp/out_${Date.now()}.webp`;
        try {
            await fs.writeFile(inputPath, inputBuffer);
            const vf = opts.pad
                ? "scale='min(512,iw)':'min(512,ih)':force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000"
                : "scale=512:512:force_original_aspect_ratio=decrease";
            ffmpeg(inputPath)
                .outputOptions(['-vcodec', 'libwebp', '-vf', vf])
                .on('end', async () => {
                    const buf = await fs.readFile(outputPath);
                    fs.unlink(inputPath).catch(() => {});
                    fs.unlink(outputPath).catch(() => {});
                    resolve(buf);
                })
                .on('error', (e) => {
                    fs.unlink(inputPath).catch(() => {});
                    reject(e);
                })
                .save(outputPath);
        } catch (e) {
            reject(e);
        }
    });
}

// Generic ffmpeg format converter
function makeMediaConverter(cmdName, targetExt, mimetype, sendAs, label) {
    return async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}${cmdName}`, 'reply to audio/video') });

        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Converting to ${label}...`) });

        const inputPath = `./tmp/in_${Date.now()}`;
        const outputPath = `./tmp/out_${Date.now()}.${targetExt}`;

        try {
            const media = await downloadTargetMedia(ctx);
            if (!media) throw new Error('Could not download media');
            await fs.writeFile(inputPath, media);

            await new Promise((resolve, reject) => {
                ffmpeg(inputPath).toFormat(targetExt).on('end', resolve).on('error', reject).save(outputPath);
            });

            const converted = await fs.readFile(outputPath);
            await ctx.bot.sendMessage(ctx.from, {
                [sendAs]: converted, mimetype,
                ...(sendAs === 'document' ? { fileName: `converted.${targetExt}` } : {}),
                caption: global.styleSuccess(`✅ Converted to ${label}`)
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        } finally {
            fs.unlink(inputPath).catch(() => {});
            fs.unlink(outputPath).catch(() => {});
        }
    };
}

module.exports = {
    category: '𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹',

    menu: (bot, from, pushName, logo) => {
        const p = global.getPrefix();
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹 ⚡
╠═════════════════╣
║ ✰〔〔 𝑨𝑼𝑫𝑰𝑶 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒕𝒐𝒎𝒑𝟑 (reply audio/video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒘𝒂𝒗 (reply audio/video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒐𝒈𝒈 (reply audio/video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒇𝒍𝒂𝒄 (reply audio/video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒎𝟒𝒂 (reply audio/video)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑽𝑰𝑫𝑬𝑶 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒕𝒐𝒎𝒑𝟒 (reply video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒂𝒗𝒊 (reply video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒈𝒊𝒇 (reply video)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑺𝑻𝑰𝑪𝑲𝑬𝑹 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒔𝒕𝒊𝒄𝒌𝒆𝒓 (reply image/video)
║┃💀┃ ➫ ${p}𝒕𝒐𝒊𝒎𝒈 (sticker → image)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑰𝑴𝑨𝑮𝑬 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒕𝒐𝒋𝒑𝒈 (reply image)
║┃💀┃ ➫ ${p}𝒕𝒐𝒑𝒏𝒈 (reply image)
║┃💀┃ ➫ ${p}𝒕𝒐𝒘𝒆𝒃𝒑 (reply image)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑭𝑰𝑳𝑬 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒕𝒐𝒛𝒊𝒑 (reply file)
║┃💀┃ ➫ ${p}𝒕𝒐𝒖𝒓𝒍 (reply file → link)
║┃💀┃ ➫ ${p}𝒕𝒐𝒃𝒂𝒔𝒆𝟔𝟒 (reply file)
║┗━━━━━━━━━━━━━━━━┛
╠═════════════════╣
║ ✰〔〔 𝑻𝑬𝑿𝑻 𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${p}𝒕𝒐𝒖𝒑𝒑𝒆𝒓 <text>
║┃💀┃ ➫ ${p}𝒕𝒐𝒍𝒐𝒘𝒆𝒓 <text>
║┃💀┃ ➫ ${p}𝒕𝒐𝒃𝒊𝒏𝒂𝒓𝒚 <text>
║┃💀┃ ➫ ${p}𝒕𝒐𝒉𝒆𝒙 <text>
║┃💀┃ ➫ ${p}𝒕𝒐𝒓𝒐𝒎𝒂𝒏 <number>
║┗━━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭 ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒕𝒐𝒎𝒑𝟑
║┃💀┃ ➫ .𝒕𝒐𝒘𝒂𝒗
║┃💀┃ ➫ .𝒕𝒐𝒐𝒈𝒈
║┃💀┃ ➫ .𝒕𝒐𝒇𝒍𝒂𝒄
║┃💀┃ ➫ .𝒕𝒐𝒎𝟒𝒂
║┃💀┃ ➫ .𝒕𝒐𝒎𝒑𝟒
║┃💀┃ ➫ .𝒕𝒐𝒂𝒗𝒊
║┃💀┃ ➫ .𝒕𝒐𝒈𝒊𝒇
║┃💀┃ ➫ .𝒔𝒕𝒊𝒄𝒌𝒆𝒓
║┃💀┃ ➫ .𝒕𝒐𝒊𝒎𝒈
║┃💀┃ ➫ .𝒕𝒐𝒋𝒑𝒈
║┃💀┃ ➫ .𝒕𝒐𝒑𝒏𝒈
║┃💀┃ ➫ .𝒕𝒐𝒘𝒆𝒃𝒑
║┃💀┃ ➫ .𝒕𝒐𝒛𝒊𝒑
║┃💀┃ ➫ .𝒕𝒐𝒖𝒓𝒍
║┃💀┃ ➫ .𝒕𝒐𝒃𝒂𝒔𝒆𝟔𝟒
║┃💀┃ ➫ .𝒕𝒐𝒖𝒑𝒑𝒆𝒓
║┃💀┃ ➫ .𝒕𝒐𝒍𝒐𝒘𝒆𝒓
║┃💀┃ ➫ .𝒕𝒐𝒃𝒊𝒏𝒂𝒓𝒚
║┃💀┃ ➫ .𝒕𝒐𝒉𝒆𝒙
║┃💀┃ ➫ .𝒕𝒐𝒓𝒐𝒎𝒂𝒏`,

    // ============================================
    // AUDIO CONVERTERS
    // ============================================

    tomp3: makeMediaConverter('tomp3', 'mp3', 'audio/mpeg', 'audio', 'MP3'),
    towav: makeMediaConverter('towav', 'wav', 'audio/wav', 'audio', 'WAV'),
    toogg: makeMediaConverter('toogg', 'ogg', 'audio/ogg', 'audio', 'OGG'),
    toflac: makeMediaConverter('toflac', 'flac', 'audio/flac', 'document', 'FLAC'),
    tom4a: makeMediaConverter('tom4a', 'm4a', 'audio/mp4', 'audio', 'M4A'),
    videotoaudio: async (ctx) => module.exports.tomp3(ctx),

    // ============================================
    // VIDEO CONVERTERS
    // ============================================

    tomp4: makeMediaConverter('tomp4', 'mp4', 'video/mp4', 'video', 'MP4'),
    toavi: makeMediaConverter('toavi', 'avi', 'video/avi', 'document', 'AVI'),
    togif: makeMediaConverter('togif', 'gif', 'image/gif', 'document', 'GIF'),

    // ============================================
    // STICKER CONVERTERS
    // ============================================

    sticker: async (ctx) => {
        const imgMsg = ctx.m.message.imageMessage || ctx.m.quoted?.message?.imageMessage;
        const vidMsg = ctx.m.message.videoMessage || ctx.m.quoted?.message?.videoMessage;
        if (!imgMsg && !vidMsg) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}sticker`, 'reply to an image or short video') });

        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Creating sticker...") });
        try {
            const media = await downloadTargetMedia(ctx);
            let stickerBuffer;
            if (imgMsg) {
                stickerBuffer = await imageToWebp(media, { pad: true });
            } else {
                const inputPath = `./tmp/in_${Date.now()}.mp4`;
                const outputPath = `./tmp/out_${Date.now()}.webp`;
                await fs.writeFile(inputPath, media);
                await new Promise((resolve, reject) => {
                    ffmpeg(inputPath)
                        .outputOptions(['-vcodec', 'libwebp', '-vf', "scale=512:512:force_original_aspect_ratio=decrease,fps=15", '-loop', '0', '-t', '6'])
                        .on('end', resolve).on('error', reject).save(outputPath);
                });
                stickerBuffer = await fs.readFile(outputPath);
                fs.unlink(inputPath).catch(() => {});
                fs.unlink(outputPath).catch(() => {});
            }
            await ctx.bot.sendMessage(ctx.from, { sticker: stickerBuffer }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Sticker creation failed: ${e.message}`) });
        }
    },

    toimg: async (ctx) => {
        const stickerMsg = ctx.m.message.stickerMessage || ctx.m.quoted?.message?.stickerMessage;
        if (!stickerMsg) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}toimg`, 'reply to a sticker') });

        try {
            const media = await downloadTargetMedia(ctx);
            const image = await Jimp.read(media);
            const imgBuffer = await image.getBuffer(JimpMime.png);
            await ctx.bot.sendMessage(ctx.from, { image: imgBuffer, caption: global.styleSuccess('✅ Converted to image') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        }
    },

    // ============================================
    // IMAGE CONVERTERS
    // ============================================

    tojpg: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tojpg`, 'reply to an image') });
        try {
            const media = await downloadTargetMedia(ctx);
            const image = await Jimp.read(media);
            const converted = await image.getBuffer(JimpMime.jpeg);
            await ctx.bot.sendMessage(ctx.from, { image: converted, caption: global.styleSuccess('✅ Converted to JPG') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        }
    },

    topng: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}topng`, 'reply to an image') });
        try {
            const media = await downloadTargetMedia(ctx);
            const image = await Jimp.read(media);
            const converted = await image.getBuffer(JimpMime.png);
            await ctx.bot.sendMessage(ctx.from, { image: converted, caption: global.styleSuccess('✅ Converted to PNG') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        }
    },

    towebp: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}towebp`, 'reply to an image') });
        try {
            const media = await downloadTargetMedia(ctx);
            const converted = await imageToWebp(media);
            await ctx.bot.sendMessage(ctx.from, { image: converted, caption: global.styleSuccess('✅ Converted to WEBP') }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        }
    },

    // ============================================
    // FILE CONVERTERS
    // ============================================

    tozip: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tozip`, 'reply to a file') });
        try {
            const media = await downloadTargetMedia(ctx);
            const zip = new AdmZip();
            zip.addFile('file', media);
            await ctx.bot.sendMessage(ctx.from, {
                document: zip.toBuffer(), mimetype: 'application/zip', fileName: 'converted.zip',
                caption: global.styleSuccess('✅ ZIP created')
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Zip creation failed: ${e.message}`) });
        }
    },

    tourl: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tourl`, 'reply to a file') });
        try {
            const media = await downloadTargetMedia(ctx);
            const formData = new FormData();
            formData.append('file', media, 'file');
            const response = await axios.post('https://file.io', formData, { headers: formData.getHeaders(), timeout: 60000 });
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`✅ Link: ${response.data.link}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Upload failed: ${e.message}`) });
        }
    },

    tobase64: async (ctx) => {
        if (!getMediaMessage(ctx)) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tobase64`, 'reply to a file') });
        try {
            const media = await downloadTargetMedia(ctx);
            const base64 = media.toString('base64');
            const truncated = base64.substring(0, 3000);
            await ctx.bot.sendMessage(ctx.from, { text: `╔═════════════════╗\n║💀║ 𝑩𝑨𝑺𝑬𝟔𝟒 (${(base64.length / 1024).toFixed(1)}KB total)\n╠═════════════════╣\n║💀║ ${truncated}${base64.length > 3000 ? '...' : ''}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Conversion failed: ${e.message}`) });
        }
    },

    // ============================================
    // TEXT CONVERTERS
    // ============================================

    toupper: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}toupper <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(ctx.text.toUpperCase()) }, { quoted: ctx.m });
    },

    tolower: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tolower <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(ctx.text.toLowerCase()) }, { quoted: ctx.m });
    },

    tobinary: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tobinary <text>`) });
        const result = ctx.text.split('').map(c => c.charCodeAt(0).toString(2).padStart(8, '0')).join(' ');
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(result.substring(0, 4000)) }, { quoted: ctx.m });
    },

    tohex: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}tohex <text>`) });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(Buffer.from(ctx.text).toString('hex')) }, { quoted: ctx.m });
    },

    toroman: async (ctx) => {
        const num = parseInt(ctx.text);
        if (!ctx.text || isNaN(num) || num <= 0 || num > 3999) return ctx.bot.sendMessage(ctx.from, { text: usage(`${global.getPrefix()}toroman <number 1-3999>`) });

        const map = [[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']];
        let n = num, result = '';
        for (const [val, sym] of map) { while (n >= val) { result += sym; n -= val; } }
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(result) }, { quoted: ctx.m });
    }
};

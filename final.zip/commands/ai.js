// ================================================
// AI CHAT COMMANDS — free Pollinations text API (no key needed)
// ================================================

const axios = require('axios');

async function askAI(prompt, model = 'openai') {
    const encoded = encodeURIComponent(prompt);
    const resp = await axios.get(`https://text.pollinations.ai/${encoded}`, {
        params: { model },
        timeout: 30000,
        responseType: 'text'
    });
    const text = String(resp.data).trim();
    if (!text) throw new Error('Empty response from AI');
    return text;
}

function makeAICommand(label, cmdName, model) {
    return async (ctx) => {
        const prompt = ctx.text || ctx.m.quoted?.text;
        if (!prompt) return ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${global.getPrefix()}${cmdName} <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });

        try {
            const answer = await askAI(prompt, model);
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 🤖 ${label}\n╠═════════════════╣\n${answer}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`AI request failed: ${e.message}`) });
        }
    };
}

module.exports = {
    category: '𝑨𝑰 𝑪𝑴𝑫𝑺',

    menu: (bot, from, pushName, logo) => {
        const menuText = `╔═════════════════╗
║💀║ ⚡ 𝑨𝑰 𝑪𝑯𝑨𝑻 ⚡
╠═════════════════╣
║ ✰〔〔 𝑨𝑰 𝑪𝑴𝑫𝑺 〕〕✰
║┏━━━━━━━━━━━━━━━━┓
║┃💀┃ ➫ ${global.getPrefix()}ai <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}gpt <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}gemini <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}llama <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}mistral <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}deepseek <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}qwen <𝒒𝒖𝒆𝒔𝒕𝒊𝒐𝒏>
║┃💀┃ ➫ ${global.getPrefix()}translate <𝒍𝒂𝒏𝒈>|<𝒕𝒆𝒙𝒕>
╚═════════════════╝

╔═════════════════╗
║💀║ 👤 𝑼𝒔𝒆𝒓: ${pushName}
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;

        if (logo) bot.sendMessage(from, { image: logo.image, caption: menuText });
        else bot.sendMessage(from, { text: menuText });
    },

    list: `║┃💀┃ ➫ .𝒂𝒊
║┃💀┃ ➫ .𝒈𝒑𝒕
║┃💀┃ ➫ .𝒈𝒆𝒎𝒊𝒏𝒊
║┃💀┃ ➫ .𝒍𝒍𝒂𝒎𝒂
║┃💀┃ ➫ .𝒎𝒊𝒔𝒕𝒓𝒂𝒍
║┃💀┃ ➫ .𝒅𝒆𝒆𝒑𝒔𝒆𝒆𝒌
║┃💀┃ ➫ .𝒒𝒘𝒆𝒏
║┃💀┃ ➫ .𝒕𝒓𝒂𝒏𝒔𝒍𝒂𝒕𝒆`,

    ai: makeAICommand('𝑨𝑰 𝑨𝒔𝒔𝒊𝒔𝒕𝒂𝒏𝒕', 'ai', 'openai'),
    gpt: makeAICommand('𝑮𝑷𝑻', 'gpt', 'openai'),
    chatgpt: makeAICommand('𝑪𝒉𝒂𝒕𝑮𝑷𝑻', 'chatgpt', 'openai'),
    gemini: makeAICommand('𝑮𝒆𝒎𝒊𝒏𝒊', 'gemini', 'gemini'),
    llama: makeAICommand('𝑳𝒍𝒂𝒎𝒂', 'llama', 'llama'),
    mistral: makeAICommand('𝑴𝒊𝒔𝒕𝒓𝒂𝒍', 'mistral', 'mistral'),
    deepseek: makeAICommand('𝑫𝒆𝒆𝒑𝑺𝒆𝒆𝒌', 'deepseek', 'deepseek-r1'),
    qwen: makeAICommand('𝑸𝒘𝒆𝒏', 'qwen', 'qwen-coder'),

    translate: async (ctx) => {
        if (!ctx.text || !ctx.text.includes('|')) return ctx.bot.sendMessage(ctx.from, {
            text: `╔═════════════════╗\n║💀║ ⚠️𝑼𝒔𝒂𝒈𝒆\n╠═════════════════╣\n║💀║ ➫ ${global.getPrefix()}translate <𝒍𝒂𝒏𝒈>|<𝒕𝒆𝒙𝒕>\n║💀║ ➫ 𝑬𝒙: ${global.getPrefix()}translate es|Hello there\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
        }, { quoted: ctx.m });

        const [lang, ...rest] = ctx.text.split('|');
        const textToTranslate = rest.join('|').trim();
        if (!textToTranslate) return ctx.bot.sendMessage(ctx.from, { text: global.styleError('Please provide text to translate') });

        try {
            const res = await axios.get('https://api.mymemory.translated.net/get', {
                params: { q: textToTranslate, langpair: `en|${lang.trim()}` },
                timeout: 20000
            });
            const translated = res.data?.responseData?.translatedText;
            if (!translated) throw new Error('No translation returned');
            await ctx.bot.sendMessage(ctx.from, {
                text: `╔═════════════════╗\n║💀║ 🌐 𝑻𝒓𝒂𝒏𝒔𝒍𝒂𝒕𝒊𝒐𝒏\n╠═════════════════╣\n║💀║ ${translated}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
            }, { quoted: ctx.m });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Translation failed: ${e.message}`) });
        }
    }
};

// ================================================
// PRIME BOT v7.0
// Pairing-code login (no QR) · Baileys 6.7.23
// ================================================

require('dotenv').config();
const config = require('./config');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    downloadMediaMessage,
    jidNormalizedUser,
    Browsers
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk');
const fs = require('fs-extra');
const path = require('path');
const readline = require('readline');
const moment = require('moment-timezone');
const axios = require('axios');

// ================================================
// DATABASE SYSTEM
// ================================================
global.db = {
    users: {},
    groups: {},
    settings: {
        public: true,
        autobio: false,
        autoread: false,
        prefix: config.prefix,
        startTime: Date.now()
    },
    premium: [],
    sudo: [],
    stats: {
        commands: 0,
        startTime: Date.now()
    },
    customCommands: {}
};

const DB_PATH = './database/database.json';
fs.ensureDirSync('./database');
fs.ensureDirSync('./session');
fs.ensureDirSync('./tmp');
fs.ensureDirSync('./commands');
fs.ensureDirSync('./Media');

if (fs.existsSync(DB_PATH)) {
    try {
        const loaded = JSON.parse(fs.readFileSync(DB_PATH));
        global.db = {
            ...global.db,
            ...loaded,
            settings: { ...global.db.settings, ...(loaded.settings || {}) },
            // always use the real process start time for uptime, never the saved value
            stats: { ...global.db.stats, ...(loaded.stats || {}), startTime: Date.now() }
        };
    } catch (e) {
        console.log(chalk.red('Database corrupted, using fresh one'));
    }
}

// Debounced save - only writes once per second max
let saveTimer = null;
global.saveDB = function () {
    if (saveTimer) return;
    saveTimer = setTimeout(() => {
        try {
            fs.writeFileSync(DB_PATH, JSON.stringify(global.db, null, 2));
        } catch (e) {}
        saveTimer = null;
    }, 1000);
};

// current effective prefix (falls back to config default)
global.getPrefix = () => global.db.settings.prefix || config.prefix;

// ================================================
// LOAD COMMAND MODULES
// ================================================
const commands = {};
const categories = {
    owner: '𝑶𝑾𝑵𝑬𝑹 𝑪𝑴𝑫𝑺',
    group: '𝑮𝑹𝑶𝑼𝑷 𝑪𝑴𝑫𝑺',
    add: '𝑨𝑫𝑫 𝑪𝑴𝑫𝑺',
    anti: '𝑨𝑵𝑻𝑰 𝑪𝑴𝑫𝑺',
    ai: '𝑨𝑰 𝑪𝑴𝑫𝑺',
    aiimage: '𝑨𝑰 𝑰𝑴𝑨𝑮𝑬',
    downloader: '𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑬𝑹',
    music: '𝑴𝑼𝑺𝑰𝑪',
    converter: '𝑪𝑶𝑵𝑽𝑬𝑹𝑻𝑬𝑹',
    tools: '𝑻𝑶𝑶𝑳𝑺'
};

const commandFiles = fs.readdirSync('./commands').filter(f => f.endsWith('.js') && !f.endsWith('.bak'));
for (const file of commandFiles) {
    try {
        const moduleName = file.replace('.js', '');
        commands[moduleName] = require(`./commands/${file}`);
        console.log(chalk.green(`✅ Loaded: ${file}`));
    } catch (e) {
        console.log(chalk.yellow(`⚠️ Failed to load ${file}: ${e.message}`));
    }
}

// Warn once at boot if ffmpeg isn't installed, instead of letting every
// media-conversion command fail with a confusing error later.
(function checkFfmpeg() {
    const { execFile } = require('child_process');
    execFile('ffmpeg', ['-version'], (err) => {
        if (err) {
            console.log(chalk.yellow('\n⚠️  ffmpeg was not found on this system.'));
            console.log(chalk.yellow('    Audio/video/sticker conversion commands (.tomp3, .tomp4, .togif, .sticker, etc.) will fail until it is installed.'));
            console.log(chalk.yellow('    Termux:  pkg install ffmpeg'));
            console.log(chalk.yellow('    Debian/Ubuntu:  sudo apt install ffmpeg'));
            console.log(chalk.yellow('    macOS (Homebrew):  brew install ffmpeg\n'));
        }
    });
})();

// ================================================
// UTILITY FUNCTIONS
// ================================================
global.isOwner = (sender) => {
    const clean = sender.split('@')[0].replace(/[^0-9]/g, '');
    return config.ownerNumbers.includes(clean);
};

global.isPremium = (sender) => {
    return global.isOwner(sender) || global.db.premium.includes(sender);
};

global.formatTime = (ms) => {
    let seconds = Math.floor(ms / 1000);
    let minutes = Math.floor(seconds / 60);
    let hours = Math.floor(minutes / 60);
    let days = Math.floor(hours / 24);
    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
};

global.sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

global.getBuffer = async (url, extraHeaders = {}) => {
    try {
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: { 'User-Agent': 'Mozilla/5.0', ...extraHeaders }
        });
        return Buffer.from(res.data);
    } catch (e) {
        return null;
    }
};

global.formatNumber = (num) => {
    let clean = String(num).replace(/\D/g, '');
    if (clean.startsWith('0')) clean = '92' + clean.substring(1);
    if (clean.length >= 10) return clean;
    return null;
};

// ================================================
// STYLING FUNCTIONS
// ================================================
global.styleHeader = (title) => `╔══════════════════════════════╗\n║💀║   ${title}\n╚══════════════════════════════╝`;
global.styleSection = (title) => `║ ✰━━┈〔 ${title} 〕 ┈━━✰`;
global.styleSuccess = (text) => `╔═════════════════╗\n║💀║   ✅ ${text}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
global.styleError = (text) => `╔═════════════════╗\n║💀║   ❌ ${text}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
global.styleProcess = (text) => `╔═════════════════╗\n║💀║   ⏳ ${text}\n╚═════════════════╝`;
global.styleInfo = (text) => `╔═════════════════╗\n║💀║   📋 ${text}\n╚═════════════════╝`;
global.styleWarning = (text) => `╔═════════════════╗\n║💀║   ⚠️ ${text}\n╚═════════════════╝`;

global.getMenuLogo = (menuName) => {
    const logoPath = config.logoPath[menuName] || config.logoPath.main;
    if (logoPath && fs.existsSync(logoPath)) {
        return { image: fs.readFileSync(logoPath) };
    }
    if (fs.existsSync(config.logoPath.main)) {
        return { image: fs.readFileSync(config.logoPath.main) };
    }
    return null;
};

// small helper to ask a question in the terminal (used for pairing number prompt)
function ask(question) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => rl.question(question, (answer) => {
        rl.close();
        resolve(answer.trim());
    }));
}

// ================================================
// MESSAGE SERIALIZER
// Extracts quoted message, mentions, media helpers etc
// so command files can rely on m.quoted / m.mentionedJid / m.download()
// ================================================
function serializeMessage(bot, m) {
    if (!m.message) return m;

    // unwrap ephemeral wrapper first
    let msgType = Object.keys(m.message)[0];
    if (msgType === 'ephemeralMessage') {
        m.message = m.message.ephemeralMessage.message;
        msgType = Object.keys(m.message)[0];
    }

    m.isViewOnce = msgType === 'viewOnceMessage' || msgType === 'viewOnceMessageV2' || msgType === 'viewOnceMessageV2Extension';
    if (m.isViewOnce) {
        m.message = m.message[msgType].message;
        msgType = Object.keys(m.message)[0];
    }

    const context = m.message[msgType]?.contextInfo;

    m.mentionedJid = context?.mentionedJid || [];

    if (context?.quotedMessage) {
        let quotedMsg = context.quotedMessage;
        let quotedType = Object.keys(quotedMsg)[0];
        let quotedIsViewOnce = quotedType === 'viewOnceMessage' || quotedType === 'viewOnceMessageV2' || quotedType === 'viewOnceMessageV2Extension';
        if (quotedIsViewOnce) {
            quotedMsg = quotedMsg[quotedType].message;
            quotedType = Object.keys(quotedMsg)[0];
        }

        m.quoted = {
            key: {
                remoteJid: m.key.remoteJid,
                fromMe: context.participant === bot.user?.id?.split(':')[0] + '@s.whatsapp.net',
                id: context.stanzaId,
                participant: context.participant
            },
            message: quotedMsg,
            sender: context.participant,
            type: quotedType,
            isViewOnce: quotedIsViewOnce,
            text: quotedMsg[quotedType]?.text
                || quotedMsg[quotedType]?.caption
                || quotedMsg.conversation
                || '',
            mentionedJid: quotedMsg[quotedType]?.contextInfo?.mentionedJid || [],
            download: () => downloadMediaMessage(
                { key: { remoteJid: m.key.remoteJid, id: context.stanzaId, participant: context.participant }, message: quotedMsg },
                'buffer', {}
            )
        };
    } else {
        m.quoted = null;
    }

    m.download = () => downloadMediaMessage(m, 'buffer', {});

    return m;
}

// Grab the target user JID from args / mentions / quoted message / reply
function resolveTarget(ctx) {
    if (ctx.m.mentionedJid && ctx.m.mentionedJid.length) return ctx.m.mentionedJid[0];
    if (ctx.m.quoted?.sender) return ctx.m.quoted.sender;
    if (ctx.args[0]) {
        const num = ctx.args[0].replace(/[^0-9]/g, '');
        if (num.length >= 8) return num + '@s.whatsapp.net';
    }
    return null;
}
global.resolveTarget = resolveTarget;

// ================================================
// GROUP PROTECTION ENFORCEMENT (antilink / antispam)
// Actually reads the settings that commands/anti.js writes and acts on them.
// ================================================
const LINK_PATTERNS = {
    antilink: /(chat\.whatsapp\.com|https?:\/\/\S+)/i,
    antilinkwa: /chat\.whatsapp\.com\/\S+/i,
    antilinkyt: /(youtube\.com|youtu\.be)\/\S+/i,
    antilinktg: /(t\.me|telegram\.me)\/\S+/i,
    antilinkfb: /(facebook\.com|fb\.watch)\/\S+/i
};

async function enforceGroupProtection(bot, m, from, sender, isAdmin, isBotAdmin, body) {
    const groupSettings = global.db.groups[from];
    if (!groupSettings) return false;
    if (isAdmin) return false; // never moderate admins
    if (!isBotAdmin) return false; // bot can't delete/kick without admin rights

    for (const [key, pattern] of Object.entries(LINK_PATTERNS)) {
        if (groupSettings[key] && pattern.test(body)) {
            try {
                await bot.sendMessage(from, { delete: m.key });
            } catch (e) {}

            if (groupSettings.antilinkkick) {
                try {
                    await bot.groupParticipantsUpdate(from, [sender], 'remove');
                    await bot.sendMessage(from, { text: global.styleWarning(`Removed @${sender.split('@')[0]} for posting a link`), mentions: [sender] });
                } catch (e) {}
            } else {
                await bot.sendMessage(from, { text: global.styleWarning(`Link detected and removed (@${sender.split('@')[0]})`), mentions: [sender] });
            }
            return true;
        }
    }
    return false;
}

// simple in-memory spam tracker: sender -> timestamps[]
const spamTracker = new Map();
async function enforceAntiSpam(bot, m, from, sender, isAdmin, isBotAdmin) {
    const groupSettings = global.db.groups[from];
    if (!groupSettings?.antispam) return false;
    if (isAdmin || !isBotAdmin) return false;

    const now = Date.now();
    const key = `${from}:${sender}`;
    const list = (spamTracker.get(key) || []).filter(t => now - t < 10000);
    list.push(now);
    spamTracker.set(key, list);

    if (list.length > 7) {
        spamTracker.set(key, []);
        try {
            await bot.sendMessage(from, { text: global.styleWarning(`@${sender.split('@')[0]} is spamming — please slow down`), mentions: [sender] });
        } catch (e) {}
        return true;
    }
    return false;
}

// ================================================
// CONNECTION
// ================================================
async function startBot() {
    console.log(chalk.cyan('\n' + '═'.repeat(50)));
    console.log(chalk.cyan.bold('🔐 PRIME BOT - STARTING'));
    console.log(chalk.cyan('═'.repeat(50)));

    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const usePairing = config.loginMethod !== 'qr';

    const bot = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: !usePairing,
        markOnlineOnConnect: true,
        logger: pino({ level: 'silent' }),
        browser: usePairing ? Browsers.ubuntu('Chrome') : Browsers.macOS('Desktop'),
        syncFullHistory: false,
        defaultQueryTimeoutMs: 60000,
        keepAliveIntervalMs: 15000
    });

    // ---- Pairing code request (with retries, since WA sometimes rejects the first attempt) ----
    if (usePairing && !bot.authState.creds.registered) {
        let phoneNumber = config.pairingNumber;
        if (!phoneNumber) {
            phoneNumber = await ask(chalk.yellow('📱 Enter the WhatsApp number to link (with country code, no + or spaces): '));
            phoneNumber = phoneNumber.replace(/\D/g, '');
        }

        if (!phoneNumber || phoneNumber.length < 8) {
            console.log(chalk.red('❌ Invalid phone number. Set PAIRING_NUMBER in .env or retype it. Restarting...'));
            process.exit(1);
        }

        const requestCode = async (attempt = 1) => {
            try {
                await global.sleep(2000); // give the socket a moment to fully init before requesting
                const code = await bot.requestPairingCode(phoneNumber);
                const formatted = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(chalk.green('\n' + '═'.repeat(50)));
                console.log(chalk.green.bold(`🔗 YOUR PAIRING CODE: ${formatted}`));
                console.log(chalk.green('═'.repeat(50)));
                console.log(chalk.white('\n1. Open WhatsApp on your phone'));
                console.log(chalk.white('2. Settings → Linked Devices → Link a Device'));
                console.log(chalk.white('3. Tap "Link with phone number instead"'));
                console.log(chalk.white(`4. Enter the code above: ${chalk.bold(formatted)}\n`));
            } catch (err) {
                console.log(chalk.red(`⚠️ Failed to generate pairing code (attempt ${attempt}): ${err.message}`));
                if (attempt < 5) {
                    await global.sleep(3000);
                    return requestCode(attempt + 1);
                }
                console.log(chalk.red('❌ Could not generate a pairing code after several attempts.'));
                console.log(chalk.yellow('   Double-check the phone number and that WhatsApp is installed & connected to the internet on that phone, then restart the bot.'));
            }
        };

        await requestCode();
    }

    bot.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr && !usePairing) {
            const qrcode = require('qrcode-terminal');
            console.log(chalk.cyan('\n📷 Scan this QR code with WhatsApp:\n'));
            qrcode.generate(qr, { small: true });
        }

        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red('\n❌ Logged out. Delete the session folder and restart to relink.'));
                process.exit(0);
            } else {
                console.log(chalk.yellow(`\n🔄 Connection closed (reason: ${reason}). Reconnecting...`));
                // tear down this socket's listeners fully before spinning up a new one,
                // otherwise the old and new sockets both stay attached to messages.upsert
                // for a few seconds and can race/drop commands sent right after a restart
                try { bot.ev.removeAllListeners(); } catch (e) {}
                try { bot.end(undefined); } catch (e) {}
                setTimeout(() => startBot(), 3000);
            }
        } else if (connection === 'open') {
            console.log(chalk.green('\n' + '═'.repeat(50)));
            console.log(chalk.green.bold('✅ CONNECTED SUCCESSFULLY!'));
            console.log(chalk.cyan(`🤖 Bot: ${config.botName}`));
            console.log(chalk.cyan(`👤 Owner: ${config.ownerNumber}`));
            console.log(chalk.cyan(`🔧 Prefix: ${global.getPrefix()}`));
            console.log(chalk.green('═'.repeat(50)));
            console.log(chalk.yellow(`\n💡 Type ${global.getPrefix()}menu in WhatsApp to see commands\n`));
        }
    });

    bot.ev.on('creds.update', saveCreds);

    // ================================================
    // MESSAGE HANDLER
    // ================================================
    bot.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        try {
            let m = messages[0];
            if (!m || !m.message) return;

            if (global.db.settings.autoread) {
                try { await bot.readMessages([m.key]); } catch (e) {}
            }

            m = serializeMessage(bot, m);

            let body = '';
            if (m.message.conversation) body = m.message.conversation;
            else if (m.message.extendedTextMessage?.text) body = m.message.extendedTextMessage.text;
            else if (m.message.imageMessage?.caption) body = m.message.imageMessage.caption;
            else if (m.message.videoMessage?.caption) body = m.message.videoMessage.caption;

            // ============================================================
            // FIX: Respond to ALL messages - NO fromMe check
            // This ensures the bot replies to commands from ANY sender,
            // including the connected number itself
            // ============================================================
            const from = m.key.remoteJid;
            const isGroup = from.endsWith('@g.us');

            // participant is only meaningful in groups; in a 1-on-1 DM it can be
            // stray/undefined depending on device sync. When the message is fromMe,
            // the real sender is always the bot's own account regardless of chat.
            const sender = jidNormalizedUser(m.key.fromMe ? bot.user?.id : (isGroup ? (m.key.participant || from) : from));
            const pushName = m.pushName || (m.key.fromMe ? (bot.user?.name || 'Owner') : 'User');
            const botNumber = jidNormalizedUser(bot.user?.id);

            let groupMetadata = {}, participants = [], groupAdmins = [], isBotAdmin = false, isAdmin = false, groupName = '';
            if (isGroup) {
                try {
                    groupMetadata = await bot.groupMetadata(from);
                    participants = groupMetadata.participants || [];
                    groupAdmins = participants.filter(p => p.admin).map(p => jidNormalizedUser(p.id));
                    isBotAdmin = groupAdmins.includes(botNumber);
                    isAdmin = groupAdmins.includes(sender) || m.key.fromMe;
                    groupName = groupMetadata.subject || '';
                } catch (e) {}
            }

            // ---- group protection runs on every group message, not just commands ----
            if (isGroup && body && !m.key.fromMe) {
                const acted = await enforceGroupProtection(bot, m, from, sender, isAdmin, isBotAdmin, body);
                if (acted) return;
                await enforceAntiSpam(bot, m, from, sender, isAdmin, isBotAdmin);
            }

            const prefix = global.getPrefix();
            if (!body || !body.startsWith(prefix)) return;

            const args = body.slice(prefix.length).trim().split(/ +/);
            const command = args.shift().toLowerCase();
            const text = args.join(' ');

            const Owner = global.isOwner(sender);
            const Premium = Owner || global.isPremium(sender);

            // respect public/private mode
            if (!global.db.settings.public && !Owner && !Premium) return;

            global.db.stats.commands++;
            global.saveDB();

            console.log(chalk.cyan(`📨 [${pushName}] ${prefix}${command}`));

            const ctx = {
                bot, from, sender, isGroup, isAdmin, isBotAdmin, Owner, Premium,
                groupMetadata, participants, groupAdmins, groupName,
                args, text, pushName, m
            };

            // ------------------------------------------------
            // BUILT-IN COMMANDS
            // ------------------------------------------------

            if (command === 'ping') {
                const start = Date.now();
                const sent = await bot.sendMessage(from, { text: '🏓 Testing...' });
                const ping = Date.now() - start;
                return await bot.sendMessage(from, {
                    text: `╔═════════════════╗\n║💀║   🏓 𝑷𝑶𝑵𝑮\n╠═════════════════╣\n║💀║ ⚡ ${ping}ms\n║💀║ 🟢 𝑩𝒐𝒕 𝑶𝒏𝒍𝒊𝒏𝒆\n║💀║ ⏱️ ${global.formatTime(Date.now() - global.db.stats.startTime)}\n╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`
                }, { quoted: m });
            }

            if (command === 'menu' || command === 'help') {
                const logo = global.getMenuLogo('main');
                const menuText = `╔═════════════════╗
║💀║   ⚡ 𝑷𝑹𝑰𝑴𝑬 𝑩𝑶𝑻 𝒗𝟕.𝟎 ⚡
╠═════════════════╣
║ ✰━━┈〔 𝑰𝑵𝑭𝑶 〕 ┈━━✰
║┏━━━━━━━━━━━━━━━━━┓
║┃💀┃ 👑 𝑫𝒆𝒗: 𝑷𝒓𝒊𝒎𝒆𝑻𝒆𝒄𝒉
║┃💀┃ 🤖 𝑩𝒐𝒕: 𝑷𝑹𝑰𝑴𝑬 𝑩𝑶𝑻
║┃💀┃ 👤 𝑼𝒔𝒆𝒓: ${pushName}
║┃💀┃ ⚙️ 𝑴𝒐𝒅𝒆: ${global.db.settings.public ? '𝑷𝑼𝑩𝑳𝑰𝑪' : '𝑷𝑹𝑰𝑽𝑨𝑻𝑬'}
║┃💀┃ 📞 𝑶𝒘𝒏𝒆𝒓: ${config.ownerNumber}
║┃💀┃ 🔧 𝑷𝒓𝒆𝒇𝒊𝒙: ${prefix}
║┃💀┃ ⏱️ 𝑼𝒑: ${global.formatTime(Date.now() - global.db.stats.startTime)}
║┗━━━━━━━━━━━━━━━┛
╚═════════════════╝

╔═════════════════╗
║💀║ 🔍 𝑻𝒚𝒑𝒆 ${prefix}𝒂𝒍𝒍𝒄𝒐𝒎𝒎𝒂𝒏𝒅𝒔
╚═════════════════╝

> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
                if (logo) return await bot.sendMessage(from, { image: logo.image, caption: menuText });
                return await bot.sendMessage(from, { text: menuText });
            }

            if (command === 'allcommands') {
                const logo = global.getMenuLogo('main');
                let allCmds = `╔═════════════════╗\n║💀║   ⚡ 𝑨𝑳𝑳 𝑪𝑶𝑴𝑴𝑨𝑵𝑫𝑺 ⚡\n╠═════════════════╣\n\n`;
                for (const [catName, catTitle] of Object.entries(categories)) {
                    if (commands[catName] && commands[catName].list) {
                        allCmds += `║ ✰━━┈〔 ${catTitle} 〕 ┈━━✰\n`;
                        allCmds += `║┏━━━━━━━━━━━━━━━━━┓\n`;
                        allCmds += commands[catName].list + '\n';
                        allCmds += `║┗━━━━━━━━━━━━━━━┛\n\n`;
                    }
                }
                allCmds += `╚═════════════════╝\n\n> _𝓟𝓻𝓲𝓶𝓮𝓣𝓮𝓬𝓱 ©𝓛𝓲𝓶𝓲𝓽𝓮𝓭  ✓_`;
                if (logo) return await bot.sendMessage(from, { image: logo.image, caption: allCmds });
                return await bot.sendMessage(from, { text: allCmds });
            }

            // Category menus
            const menuHandlers = {
                ownermenu: 'owner', groupmenu: 'group', addmenu: 'add', antimenu: 'anti',
                aimenu: 'ai', imagemenu: 'aiimage', downloadermenu: 'downloader',
                musicmenu: 'music', convertermenu: 'converter', toolsmenu: 'tools'
            };

            if (menuHandlers[command]) {
                const mod = commands[menuHandlers[command]];
                if (mod?.menu) await mod.menu(bot, from, pushName, global.getMenuLogo(menuHandlers[command]));
                return;
            }

            // Dispatch to command modules
            for (const moduleName of Object.keys(commands)) {
                if (commands[moduleName][command]) {
                    try {
                        await commands[moduleName][command](ctx);
                    } catch (e) {
                        console.log(chalk.red(`Error in ${prefix}${command}: ${e.message}`));
                        try {
                            await bot.sendMessage(from, { text: global.styleError(`Command error: ${e.message}`) });
                        } catch (_) {}
                    }
                    return;
                }
            }

        } catch (error) {
            console.log(chalk.red('Message handler error:'), error.message);
        }
    });

    // ================================================
    // AUTO WELCOME / GOODBYE
    // ================================================
    bot.ev.on('group-participants.update', async (update) => {
        try {
            const { id, participants, action } = update;
            const settings = global.db.groups[id];
            if (!settings) return;

            let groupMetadata;
            try { groupMetadata = await bot.groupMetadata(id); } catch (e) { return; }

            for (const participant of participants) {
                if (action === 'add' && settings.welcomeText) {
                    const text = settings.welcomeText
                        .replace(/@user/gi, `@${participant.split('@')[0]}`)
                        .replace(/@group/gi, groupMetadata.subject);
                    await bot.sendMessage(id, { text, mentions: [participant] });
                } else if (action === 'remove' && settings.goodbyeText) {
                    const text = settings.goodbyeText
                        .replace(/@user/gi, `@${participant.split('@')[0]}`)
                        .replace(/@group/gi, groupMetadata.subject);
                    await bot.sendMessage(id, { text, mentions: [participant] });
                }
            }
        } catch (e) {}
    });

    return bot;
}

// ================================================
// START
// ================================================
startBot().catch(err => {
    console.error(chalk.red('Fatal error:'), err);
    process.exit(1);
});

process.stdin.resume();

process.on('SIGINT', () => {
    console.log(chalk.yellow('\n👋 Bot stopped'));
    global.saveDB();
    setTimeout(() => process.exit(0), 1200);
});

process.on('uncaughtException', (err) => {
    console.log(chalk.red('Uncaught Exception:'), err.message);
});

process.on('unhandledRejection', (err) => {
    console.log(chalk.red('Unhandled Rejection:'), err?.message || err);
});

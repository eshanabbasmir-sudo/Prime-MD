# PRIME BOT v7.0

A WhatsApp bot built on Baileys, using **pairing-code login** (no QR code needed).

## What changed in this rebuild

- **Pairing code login** — connects with a phone-number code instead of scanning a QR, with automatic retries if the first attempt fails.
- **Fixed message handling** — commands now actually respond after connecting (the previous build had no working reply pipeline for quoted messages, mentions, or media downloads).
- **Default prefix is `.`**
- **Real quoted-message / mention support** — `.kick @user`, replying to a message with `.sticker`, etc. now work, because the bot properly reads WhatsApp's quoted-message data instead of assuming a property that never existed.
- **Anti-link / anti-spam actually enforce** — toggling `.antilink on` now really deletes matching messages (and optionally kicks), instead of just flipping a setting that nothing read.
- **Downloader/converter/music commands only include things backed by a real, working API** — no "coming soon" filler commands. A handful of dead file-hosting services (Zippyshare, AnonFiles, etc., which have shut down) and made-up model names were removed rather than left broken.
- **Every command category has its own banner image** in `/Media`.

## Not included

Two files from the original project — `bug.js` and `gccrasher.js` — are **not** part of this rebuild. Those were WhatsApp crash/flood tools, and building or "fixing" that kind of thing isn't something I'll help with, regardless of how it's marketed. Same for a covert "extract all group members to owner" command that used to live in owner.js — that's silent surveillance of group members, not a feature.

## Setup

1. Install [Node.js](https://nodejs.org) 18 or newer.
2. Install [ffmpeg](https://ffmpeg.org/download.html) and make sure it's on your PATH (needed for audio/video/sticker conversion).
3. Unzip this project, open a terminal in the folder, then run:
   ```
   npm install
   ```

### If you're hosting on Termux (Android)

- Install ffmpeg via Termux's package manager, not npm: `pkg install ffmpeg`
- Image conversion uses `jimp` (pure JavaScript) instead of `sharp`, specifically because `sharp` ships native binaries that often aren't prebuilt for `android-arm64`/Termux and fail to install. `jimp` has no native dependencies, so it installs cleanly on Termux. (Using `jimp@^1.x` specifically, since that's what Baileys 6.7.23 expects as a peer dependency — installing an older `jimp@0.x` alongside it causes an `ERESOLVE` conflict during `npm install`.)
- Termux is fine for testing, but the OS can kill the process in the background (battery optimization, app being swiped away) and a phone reboot takes the bot down too. For anything you want reliably online 24/7, a real VM (e.g. Oracle Cloud's free tier) is more dependable than a phone.
- **Sandboxed dev environments (Daytona, Replit, similar coding sandboxes) are not suitable for hosting this bot.** They can rebuild or reset their filesystem between sessions, which corrupts the `session/` folder Baileys depends on for its encryption keys — this shows up as `Bad MAC` / `Failed to decrypt message with any known session` errors and the bot going unresponsive right after connecting. If you hit that error, it's not a bug in the bot; wipe `session/`, remove the linked device from WhatsApp, and re-pair — but if it keeps happening, switch to a real persistent host (a VPS, a dedicated always-on VM, or Termux on a phone that stays on).

4. Copy `.env` and fill in your details (owner number is already set, but double check it):
   ```
   OWNER_NUMBER=923489801946
   PAIRING_NUMBER=          # your bot's WhatsApp number, or leave blank to be asked at startup
   ```
5. Start the bot:
   ```
   npm start
   ```
6. You'll see a pairing code printed in the terminal, e.g. `ABCD-1234`. On the phone that will run the bot:
   - Open WhatsApp → **Settings → Linked Devices → Link a Device**
   - Tap **"Link with phone number instead"**
   - Enter the code shown in your terminal
7. Once connected, message the bot with `.menu` to see the main menu, or `.allcommands` to see everything.

## Configuration

Everything lives in `config.js` and `.env`:
- `OWNER_NUMBER` / `OWNER_NUMBERS` — who gets owner-level access
- `PAIRING_NUMBER` — the bot's own WhatsApp number for pairing
- Prefix can be changed live with `.setprefix <new prefix>` (owner only)

Optional free API keys (the bot works fine without them, these just unlock extra commands):
- `PEXELS_API_KEY` — free from https://www.pexels.com/api/, powers `.img`

## A note on the downloader/music commands

Public "free" scraping APIs for platforms like Instagram, Facebook, and YouTube break constantly and often violate those platforms' terms of service. Rather than wire in a dozen fragile, ad-laden scraper endpoints and call it "100% working," this build sticks to sources that are documented and stable (TikTok's tiklydown API, YouTube search/oEmbed, lyrics.ovh, Google Translate TTS, wttr.in weather, etc.). If a command isn't there, it's because there wasn't a real, reliable free API behind it — not because it was left half-built.

## Support

Developer: PrimeTech

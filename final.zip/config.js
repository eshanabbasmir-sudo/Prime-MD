// ================================================
// PRIME BOT v7.0 - CONFIGURATION
// ================================================

require('dotenv').config();

module.exports = {
    developer: "PrimeTech",
    botName: "𝐏𝐑𝐈𝐌𝐄 𝐁𝐎𝐓",
    version: "7.0",

    // Default command prefix. Can be changed at runtime with .setprefix
    // (runtime value lives in the database so it survives restarts).
    prefix: ".",

    ownerNumber: (process.env.OWNER_NUMBER || "923489801946").replace(/\D/g, ''),
    ownerNumbers: (process.env.OWNER_NUMBERS || "923489801946,923554707642,923554503286")
        .split(',')
        .map(n => n.replace(/\D/g, ''))
        .filter(Boolean),

    supportMail: "primetech3310@gmail.com",

    // Login method: "pairing" (recommended, no QR) or "qr"
    loginMethod: (process.env.LOGIN_METHOD || "pairing").toLowerCase(),
    // Phone number used to request a pairing code (with country code, no + or spaces)
    // Can be left blank to be prompted for it in the terminal at startup.
    pairingNumber: (process.env.PAIRING_NUMBER || "").replace(/\D/g, ''),

    publicMode: true,
    autoRead: false,
    packname: "PrimeBot",
    author: "PrimeTech",

    apis: {
        weather: process.env.WEATHER_API_KEY || "",
        removebg: process.env.REMOVEBG_API_KEY || "",
        pexels: process.env.PEXELS_API_KEY || ""
    },

    logoPath: {
        main: "./logo.png",
        owner: "./Media/owner.png",
        group: "./Media/group.png",
        add: "./Media/add.png",
        anti: "./Media/anti.png",
        ai: "./Media/ai.png",
        aiimage: "./Media/aiimage.png",
        downloader: "./Media/downloader.png",
        music: "./Media/music.png",
        converter: "./Media/converter.png",
        tools: "./Media/tools.png"
    },

    databasePath: "./database/",

    mess: {
        owner: "❌ Owner only command!",
        premium: "❌ Premium only command!",
        admin: "❌ Admin only command!",
        group: "❌ Group only command!",
        botAdmin: "❌ Bot must be admin first!",
        done: "✅ Done!",
        error: "❌ Error occurred!",
        success: "✅ Success!"
    }
};
